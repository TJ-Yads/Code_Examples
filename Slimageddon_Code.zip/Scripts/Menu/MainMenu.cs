﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    private StatsManager statManager;
    public GameObject Controls, Menu, Difficulty, GameMode, Trophy, Stats, TrophyHow;
    public void ChangeScene(int sceneNumber)
    {
        SceneManager.LoadScene(sceneNumber);
        Time.timeScale = 1;
    }
    public void ShowDifficulty()
    {
        Difficulty.SetActive(true);
        GameMode.SetActive(false);
        Controls.SetActive(false);
        Menu.SetActive(false);
    }
    public void ShowGameMode()
    {
        Difficulty.SetActive(false);
        GameMode.SetActive(true);
        Controls.SetActive(false);
        Menu.SetActive(false);
    }
    public void ShowControls()
    {
        Controls.SetActive(true);
        Menu.SetActive(false);
    }
    public void ReturnToMenu()
    {
        Difficulty.SetActive(false);
        GameMode.SetActive(false);
        Controls.SetActive(false);
        Menu.SetActive(true);
        Trophy.SetActive(false);
        Stats.SetActive(false);
    }
    public void Quit()
    {
        Application.Quit();
    }
    public void ShowTrophy()
    {
        Difficulty.SetActive(false);
        GameMode.SetActive(false);
        Controls.SetActive(false);
        Menu.SetActive(false);
        Trophy.SetActive(true);
        Stats.SetActive(false);
        TrophyHow.SetActive(false);
    }
    public void ShowStats()
    {
        GameObject GameMangerOBJ = GameObject.FindWithTag("GameManage");
        statManager = GameMangerOBJ.GetComponent<StatsManager>();
        statManager.LoadPrefs();
        Difficulty.SetActive(false);
        GameMode.SetActive(false);
        Controls.SetActive(false);
        Menu.SetActive(false);
        Trophy.SetActive(false);
        Stats.SetActive(true);
    }
    public void ShowTrophyHow()
    {
        TrophyHow.SetActive(true);
        Trophy.SetActive(false);
    }
}
  