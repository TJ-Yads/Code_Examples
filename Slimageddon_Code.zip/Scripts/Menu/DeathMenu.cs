﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DeathMenu : MonoBehaviour
{
    public GameObject Menu;
    public int Kills;
    public float Size, TimeAlive;
    private PlayerController playercontroller;
    public Text KillsTex, KillsTex2, SizeTex, SizeTex2;
    private float counter = 0;
    private float lifetime = 2;
    public bool Dead, Timed;
    // Start is called before the first frame update
    void Start()
    {
        GameObject PlayerControllerObject = GameObject.FindWithTag("Player");
        playercontroller = PlayerControllerObject.GetComponent<PlayerController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Dead == true)
        {
            counter += Time.deltaTime;
            if (counter >= lifetime)
            {
                ShowMenu();
                Dead = false;
            }
        }
    }
    public void ShowMenu()
    {
        Cursor.visible = true;
        Size = Mathf.Round(Size * 100f) / 10f;
        Menu.SetActive(true);
        KillsTex.text = "You absorbed " + Kills + " other slime(s).";
        KillsTex2.text = "You absorbed " + Kills + " other slime(s).";
        SizeTex.text = "You grew to a size of " + Size + " lbs";
        SizeTex2.text = "You grew to a size of " + Size + " lbs";
        if (Timed == true)
        {
            TimeAlive = Mathf.Round(TimeAlive * 100f) / 100f;
            SizeTex.text = "You survivied for " + TimeAlive + "s";
            SizeTex2.text = "You survivied for " + TimeAlive + "s";
        }
    }
}
