﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrophyPowers : MonoBehaviour
{
    public int Jumps;
    public float Crush, Size;
    public bool CloudBonus, SlamBonus, SurvivialBonus, WorldBonus, PaulBonus, ARTBonus;
    public void CloudBonusM()
    {
        CloudBonus = !CloudBonus;
        if (CloudBonus == true)
        {
            Jumps += 1;
        }
        else
            Jumps -= 1;
    }
    public void SlamBonusM()
    {
        SlamBonus = !SlamBonus;
        if (SlamBonus == true)
        {
            Crush += .1f;
        }
        else
            Crush -= .1f;
    }
    public void SurvivialBonusM()
    {
        SurvivialBonus = !SurvivialBonus;
        if (SurvivialBonus == true)
        {
            Size += .1f;
        }
        else
            Size -= .1f;
    }
    public void WorldBonusM()
    {
        WorldBonus = !WorldBonus;
        if (WorldBonus == true)
        {
            Size += .5f;
        }
        else
            Size -= .5f;
    }
    public void PaulBonusM()
    {
        PaulBonus = !PaulBonus;
        if (PaulBonus == true)
        {
            Size += .5f;
        }
        else
            Size -= .5f;
    }
    public void ARTBonusM()
    {
        ARTBonus = !ARTBonus;
        if (ARTBonus == true)
        {
            Crush += .1f;
        }
        else
            Crush -= .1f;
    }
    public void ResetPowers()
    {
        CloudBonus = false;
        SlamBonus = false;
        SurvivialBonus = false;
        WorldBonus = false;
        PaulBonus = false;
        Jumps = 0;
        Crush = 0;
        Size = 0;
    }
}
