﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerButtons : MonoBehaviour
{
    private GameManage gameManager;
    private TrophyPowers TPower;
    // Start is called before the first frame update
    void Start()
    {
        GameObject GameMangerOBJ = GameObject.FindWithTag("GameManage");
        gameManager = GameMangerOBJ.GetComponent<GameManage>();
        TPower = GameMangerOBJ.GetComponent<TrophyPowers>();
        TPower.ResetPowers();
    }
    public void Survivial()
    {
        gameManager.PlaySurvive();
    }
    public void Normal()
    {
        gameManager.PlayNormal();
    }
    public void Attrition()
    {
        gameManager.Atrrition();
    }
    public void Easy()
    {
        gameManager.Easy();
    }
    public void Medium()
    {
        gameManager.Medium();
    }
    public void Hard()
    {
        gameManager.Hard();
    }
    public void Cloud()
    {
        TPower.CloudBonusM();
    }
    public void Slam()
    {
        TPower.SlamBonusM();
    }
    public void Survived()
    {
        TPower.SurvivialBonusM();
    }
    public void World()
    {
        TPower.WorldBonusM();
    }
    public void Paul()
    {
        TPower.PaulBonusM();
    }
    public void ARTSurvive()
    {
        TPower.ARTBonusM();
    }
}
