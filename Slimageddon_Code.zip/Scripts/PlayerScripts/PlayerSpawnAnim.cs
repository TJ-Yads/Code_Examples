﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpawnAnim : MonoBehaviour
{
    private PlayerController playercontroller;
    // Start is called before the first frame update
    void Start()
    {
        GameObject PlayerControllerObject = GameObject.FindWithTag("Player");
        playercontroller = PlayerControllerObject.GetComponent<PlayerController>();
        StartCoroutine(Spawn());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public IEnumerator Spawn()
    {
        while (true)
        {
            for (int i = 0; i < 10; i++)
            {
                transform.localScale += new Vector3(.1f, .1f, 0);
                yield return new WaitForSeconds(.25f);
            }
            yield return new WaitForSeconds(.5f);
            SpriteRenderer PlayerSprite = playercontroller.GetComponent<SpriteRenderer>();
            PlayerSprite.color = new Color(1, 1, 1, 1);
            playercontroller.CanMove = true;
            playercontroller.SpawnSpawnFX();
            Destroy(gameObject);
        }
    }
}
