﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollower : MonoBehaviour
{
    private PlayerController playercontroller;
    public GameObject player;

    public Vector3 offset;
    private float OffZ;
    // Start is called before the first frame update
    void Start()
    {
        GameObject playerControllerObject = GameObject.FindWithTag("Player");
        playercontroller = playerControllerObject.GetComponent<PlayerController>();
        offset = transform.position - player.transform.position;
        UpdateOffset();
    }

    void LateUpdate()
    {
        transform.position = player.transform.position + offset;
        if (playercontroller.SizedUp)
        {
            UpdateOffset();
            playercontroller.SizedUp = false;
        }
    }
    void UpdateOffset()
    {
        OffZ = (player.transform.position.z - 15) - playercontroller.Size * 3.5f;
        offset = new Vector3(0, 0, OffZ);
    }
}
