﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimations : MonoBehaviour
{
    private PlayerController playercontroller;
    public Animator anim;
    private float counter = 0, counter2 = 0;
    private float lifetime = 8, lifetime2 = .5f;
    public AudioSource AMove, ALand;
    private bool AMoveOn, ALandOn;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        GameObject playerControllerObject = GameObject.FindWithTag("Player");
        playercontroller = playerControllerObject.GetComponent<PlayerController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (playercontroller.rb.velocity.x > 0 ^ playercontroller.rb.velocity.x < 0)
        {
            if (AMoveOn == false && playercontroller.Falling == false)
            {
                AMoveOn = true;
                AMove.Play();
            }
            anim.ResetTrigger("Stopped");
            anim.SetTrigger("Moving");
            counter = 0;
            if (playercontroller.rb.velocity.x > 0)
            {
                playercontroller.sr.flipX = false;
            }
            else
                playercontroller.sr.flipX = true;
        }
        if (playercontroller.rb.velocity.x == 0)
        {
            if (AMoveOn == true ^ playercontroller.Falling == true)
            {
                AMoveOn = false;
                AMove.Stop();
            }
            anim.SetTrigger("Stopped");
            anim.ResetTrigger("Moving");
        }
        if(playercontroller.Jumped == true)
        {
            counter = 0;
            playercontroller.Jumped = false;
            anim.ResetTrigger("Stopped");
            anim.ResetTrigger("Moving");
            anim.SetTrigger("Jumped");
            anim.ResetTrigger("Landed");
            anim.ResetTrigger("Falling");
        }
        if (playercontroller.Falling == true)
        {
            //anim.ResetTrigger("Landed");
            //anim.SetTrigger("Falling");
            counter2 += Time.deltaTime;
           if (counter2 >= lifetime2 ^ playercontroller.Crush > 1)
           {
                ALandOn = false;
                counter2 = 0;
                anim.ResetTrigger("Landed");
                anim.SetTrigger("Falling");
           }
        }
        if (playercontroller.Landed == true)
        {
            if (ALandOn == false)
            {
                ALandOn = true;
                ALand.Play();
            }
            counter2 = 0;
            anim.ResetTrigger("Jumped");
            anim.ResetTrigger("Falling");
            anim.SetTrigger("Landed");
        }
        counter += Time.deltaTime;
        if (counter >= lifetime)
        {
            anim.ResetTrigger("Stopped");
            anim.SetTrigger("Sleeping");
        } 
    }
}
