﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ENVDestroyer : MonoBehaviour
{
    private StatsManager statManager;
    private PlayerController playercontroller;
    public float SizeX, SizeY, Power, Health;
    public GameObject DestroyFX;
    public Transform FXSpawn;
    public bool IsCloud, IsDirt, IsRock;
    // Start is called before the first frame update
    void Start()
    {
        GameObject playerControllerObject = GameObject.FindWithTag("Player");
        playercontroller = playerControllerObject.GetComponent<PlayerController>();
        GameObject GameMangerOBJ = GameObject.FindWithTag("GameManage");
        statManager = GameMangerOBJ.GetComponent<StatsManager>();
        Power = SizeX * SizeY;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            if (playercontroller.Power * playercontroller.Crush > Power * 1.2 && playercontroller.Crush > 1 ^ playercontroller.Power > Power * 1.9)
            {
                Instantiate(DestroyFX, FXSpawn.position, FXSpawn.rotation);
                playercontroller.Crush = 1;
                playercontroller.DesObjs += 1;
                playercontroller.SizedUp = true;
                playercontroller.UpdateSize(Health);
                playercontroller.SpawnAbsorbFX();
                playercontroller.Jumps = playercontroller.JumpLimit;
                if (IsCloud == true)
                {
                    statManager.CloudsEaten += 1;
                }
                Destroy(this.gameObject);
            }
        }
        if (other.tag == "Enemy")
        {
            EnemyAI EnemyTarget = other.GetComponent<EnemyAI>();
            if (EnemyTarget.Power > Power * 1.6)
            {
                Instantiate(DestroyFX, FXSpawn.position, FXSpawn.rotation);
                EnemyTarget.Size += .01f;
                EnemyTarget.UpdateSize();
                Destroy(this.gameObject);
            }
        }
    }
}
