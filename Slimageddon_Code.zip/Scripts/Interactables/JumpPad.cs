﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpPad : MonoBehaviour
{
    public int Power;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            GameObject PlayerControllerObject = GameObject.FindWithTag("Player");
            PlayerController playercontroller = PlayerControllerObject.GetComponent<PlayerController>();
            playercontroller.Jumps = playercontroller.JumpLimit;
            collision.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, Power);
        }
        if (collision.tag == "Enemy")
        {
            collision.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(5, Power);
        }
    }
}
