﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StumpTraveler : MonoBehaviour
{
    private GameObject PlayerControllerObject;
    public Transform WarpPoint, StartPoint;
    public GameObject KillZone;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            PlayerControllerObject = GameObject.FindWithTag("Player");
            if (PlayerControllerObject.GetComponent<PlayerController>().Crush > 1)
            {
                StartCoroutine(Warp());
            }
        }
    }
    public IEnumerator Warp()
    {
        PlayerControllerObject.GetComponent<PlayerController>().Crush = 1;
        PlayerControllerObject.GetComponent<PlayerController>().CanMove = false;
        SpriteRenderer PlayerSprite = PlayerControllerObject.GetComponent<SpriteRenderer>();
        PlayerControllerObject.GetComponent<PlayerController>().CrushFX.SetActive(false);
        PlayerSprite.color = new Color(0, 0, 0, 0);
        PlayerControllerObject.transform.position = StartPoint.position + new Vector3(0, 2, 0);
        Instantiate(KillZone, WarpPoint.position, WarpPoint.rotation);
        yield return new WaitForSeconds(.33f);
        PlayerControllerObject.transform.position = WarpPoint.position + new Vector3(0, 2, 0);
        PlayerControllerObject.GetComponent<PlayerController>().Jump = true;
        PlayerSprite.color = new Color(1, 1, 1, 1);
        PlayerControllerObject.transform.position = WarpPoint.position + new Vector3(0, 2, 0);
        PlayerControllerObject.GetComponent<PlayerController>().CanMove = true;
    }
}
