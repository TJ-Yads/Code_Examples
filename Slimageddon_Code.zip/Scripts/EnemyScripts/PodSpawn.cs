﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PodSpawn : MonoBehaviour
{
    public float Value;
    public GameObject Enemy, CloudE, BaseE, Paul, IronE;
    public GameObject GreenPod, WhitePod, RockPod;
    public Transform SpawnPoint;
    private int Roll;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Scaler());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public IEnumerator Scaler()
    {
        Enemy = BaseE;
        if (SpawnPoint.position.y > 30)
        {
            WhitePod.SetActive(true);
            GreenPod.SetActive(false);
            Enemy = CloudE;
        }
        if (SpawnPoint.position.y < -1)
        {
            Enemy = IronE;
        }
        Roll = Random.Range(1, 101);
        if (Roll == 100)
        {
            Enemy = Paul;
        }
        while (true)
        {
            for (int i = 0; i < 10; i++)
            {
                transform.localScale += new Vector3(Value, Value, 0);
                yield return new WaitForSeconds(.5f);
            }
            yield return new WaitForSeconds(1f);
            Instantiate(Enemy, SpawnPoint.position, SpawnPoint.rotation);
            Destroy(gameObject);
        }
    }
}
