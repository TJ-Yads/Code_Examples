﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject Enemy;
    public int EnemyCount;
    public float SpawnWait, WaveWait, startWait, DisX, DisY, MaxDis;
    GameObject[] spawnPoints;
    GameObject currentPoint;
    GameObject LastPoint;
    int index;
    public Transform SpawnPoint;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(EnemySpawner());
    }

    public IEnumerator EnemySpawner()
    {
        yield return new WaitForSeconds(startWait);
        while (true)
        {
            for (int i = 0; i < EnemyCount; i++)
            {
                Transform Player = GameObject.FindWithTag("Player").transform;
                spawnPoints = GameObject.FindGameObjectsWithTag("Spawn");
                index = Random.Range(0, spawnPoints.Length);
                currentPoint = spawnPoints[index];
                DisX = Mathf.Abs(Player.position.x - currentPoint.transform.position.x);
                DisY = Mathf.Abs(Player.position.y - currentPoint.transform.position.y);
                if (currentPoint != LastPoint && DisY < MaxDis && DisX < MaxDis)
                {
                    Instantiate(Enemy, currentPoint.transform);
                    LastPoint = currentPoint;
                }
                else
                {
                    i -= 1;
                }
                yield return new WaitForSeconds(SpawnWait);
            }
            yield return new WaitForSeconds(WaveWait);
        }
    }
}
