﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelGenerator : MonoBehaviour
{
    public GameObject[] MidLevels, TopLevels, BottomLevels;
    public Transform[] LevelPoints, TopPoints, BottomPoints;
    int index;
    GameObject currentPoint;
    // Start is called before the first frame update
    void Start()
    {
        foreach(Transform Points in LevelPoints)
        {
            index = Random.Range(0, MidLevels.Length);
            currentPoint = MidLevels[index];
            Instantiate(currentPoint, Points);
        }
        foreach (Transform Points in TopPoints)
        {
            index = Random.Range(0, TopLevels.Length);
            currentPoint = TopLevels[index];
            Instantiate(currentPoint, Points);
        }
        foreach (Transform Points in BottomPoints)
        {
            index = Random.Range(0, BottomLevels.Length);
            currentPoint = BottomLevels[index];
            Instantiate(currentPoint, Points);
        }
    }
}
