﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManage : MonoBehaviour
{
    public int Survivial, Atr;
    public float MinUp, MaxUp, Timer;
    void Awake()
    {
        GameObject[] objs = GameObject.FindGameObjectsWithTag("GameManage");

        if (objs.Length > 1)
        {
            Destroy(this.gameObject);
        }
        DontDestroyOnLoad(this);
    }
    public void PlaySurvive()
    {
        Survivial = 0;
        Atr = 0;
    }
    public void PlayNormal()
    {
        Survivial = 1;
        Atr = 0;
    }
    public void Atrrition()
    {
        Survivial = 1;
        Atr = 1;
    }
    public void Easy()
    {
        Timer = 10f;
        MinUp = .25f;
        MaxUp = -.25f;
    }
    public void Medium()
    {
        Timer = 0;
        MinUp = 0;
        MaxUp = 0;
    }
    public void Hard()
    {
        Timer = -10f;
        MinUp = -.25f;
        MaxUp = .25f;
    }
}
