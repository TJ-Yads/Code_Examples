﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SurvivialManager : MonoBehaviour
{
    public float Size;
    private GameManage gameManager;
    // Start is called before the first frame update
    void Start()
    {
        GameObject GameMangerOBJ = GameObject.FindWithTag("GameManage");
        gameManager = GameMangerOBJ.GetComponent<GameManage>();
        StartCoroutine(Survivial());
    }

    public IEnumerator Survivial()
    {
        while (true)
        {
            yield return new WaitForSeconds(30.0f + gameManager.Timer);
            Size += .5f;
        }
    }
}
