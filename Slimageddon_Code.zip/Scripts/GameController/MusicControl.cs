﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicControl : MonoBehaviour
{
    public AudioSource Mid, Upper, Lower;
    public Collider2D MidCol, UpperCol, LowerCol;
    private bool MidOn, UpperOn, LowerOn;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player" && collision.IsTouching(MidCol) && MidOn == false)
        {
            MidOn = true;
            StartCoroutine(MidSong());
        }
        if (collision.tag == "Player" && collision.IsTouching(UpperCol) && UpperOn == false)
        {
            UpperOn = true;
            StartCoroutine(UpperSong());
        }
        if (collision.tag == "Player" && collision.IsTouching(LowerCol) && LowerOn == false)
        {
            LowerOn = true;
            StartCoroutine(LowerSong());
        }
    }

    public IEnumerator MidSong()
    {
        if (Lower.volume > 0)
        {
            StartCoroutine(StopLowerSong());
        }
        if (Upper.volume > 0)
        {
            StartCoroutine(StopUpperSong());
        }
        Mid.UnPause();
        Mid.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume += .05f;
    }
    public IEnumerator UpperSong()
    {
        StartCoroutine(StopMidSong());
        Upper.UnPause();
        Upper.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume += .05f;
    }
    public IEnumerator LowerSong()
    {
        StartCoroutine(StopMidSong());
        Lower.UnPause();
        Lower.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume += .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume += .05f;
    }
    public IEnumerator StopLowerSong()
    {
        Lower.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Lower.volume -= .05f;
        Lower.Pause();
        LowerOn = false;
    }
    public IEnumerator StopUpperSong()
    {
        Upper.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Upper.volume -= .05f;
        Upper.Pause();
        LowerOn = false;
    }
    public IEnumerator StopMidSong()
    {
        Mid.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume -= .05f;
        yield return new WaitForSeconds(.8f);
        Mid.volume -= .05f;
        Mid.Pause();
        MidOn = false;
    }
}
