﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parralax : MonoBehaviour
{
    public float Speed, ParaSpeed;
    private PlayerController playercontroller;
    // Start is called before the first frame update
    void Start()
    {
        GameObject PlayerControllerObject = GameObject.FindWithTag("Player");
        playercontroller = PlayerControllerObject.GetComponent<PlayerController>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Speed = playercontroller.speed * playercontroller.movement / ParaSpeed;
        transform.position += transform.right * Speed;
    }
}
