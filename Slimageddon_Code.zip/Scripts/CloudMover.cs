﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloudMover : MonoBehaviour
{
    public GameObject Parent, Child;
    private float speed;

    private Rigidbody2D rb;
    // Use this for initialization
    void Start()
    {
        Parent = GameObject.FindWithTag("ParentBind");
        Child.transform.parent = Parent.transform;
        speed = Random.Range(1, 4);
        rb = GetComponent<Rigidbody2D>();
        rb.velocity = transform.right * speed;
    }
}
