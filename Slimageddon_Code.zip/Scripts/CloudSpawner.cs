﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloudSpawner : MonoBehaviour
{
    public GameObject[] Clouds;
    private GameObject CurrentCloud;
    public float MaxY, MinY;
    public Transform SpawnPoint, Parenter;
    private int Index;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(CloudSpawn());
    }
    public IEnumerator CloudSpawn()
    {
        yield return new WaitForSeconds(.5f);
        while (true)
        {
            for (int i = 0; i < 5; i++)
            {
                yield return new WaitForSeconds(5f);
                Index = Random.Range(0, Clouds.Length);
                CurrentCloud = Clouds[Index];
                Vector3 PointY = new Vector3(-250, Random.Range(MinY, MaxY), 0.0f);
                Quaternion PointRotate = new Quaternion(0.0f, 0.0f, 0.0f, 0.0f);
                SpawnPoint.SetPositionAndRotation(PointY, PointRotate);
                Instantiate(CurrentCloud, SpawnPoint.transform);
            }
        }
    }
}
