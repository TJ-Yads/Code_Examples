﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceCost : MonoBehaviour
{
    public int Wood, Stone, Gold, Food;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void BarracksCost()
    {
        //100
        Wood = 25;
        Stone = 35;
        Gold = 25;
        Food = 15;
    }
    public void StoreHouseCost()
    {
        //80
        Wood = 20;
        Stone = 20;
        Gold = 20;
        Food = 20;
    }
    public void FarmCost()
    {
        //40
        Wood = 10;
        Stone = 10;
        Gold = 20;
        Food = 0;
    }
    public void Mill()
    {
        //40
        Stone = 20;
        Wood = 20;
        Gold = 0;
        Food = 0;
    }
    public void MiningCampCost()
    {
        //40
        Wood = 20;
        Stone = 0;
        Gold = 0;
        Food = 20;
    }
    public void LumberYardCost()
    {
        //40
        Wood = 0;
        Stone = 20;
        Gold = 10;
        Food = 10;
    }
    public void WatchtowerCost()
    {
        //120
        Wood = 60;
        Stone = 20;
        Gold = 20;
        Food = 20;
    }
    public void ResearchCenterCost()
    {
        //200
        Wood = 50;
        Stone = 50;
        Gold = 50;
        Food = 50;
    }
    public void HouseCost()
    {
        //60
        Wood = 20;
        Stone = 20;
        Food = 20;
        Gold = 0;
    }
}
