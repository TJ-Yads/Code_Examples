﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DifficultyManager : MonoBehaviour
{
    public int DifficultyValue;
    public Text DiffDMG, DiffRes, DiffHealth, Diff;
    // Start is called before the first frame update
    void Start()
    {
    }
    void Awake()
    {
        GameObject[] objs = GameObject.FindGameObjectsWithTag("Difficulty");

        if (objs.Length > 1)
        {
            Destroy(this.gameObject);
        }
        DontDestroyOnLoad(this);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    public void DifficultyNum(int DiffNum)
    {
        DifficultyValue = DiffNum;
        if (DiffNum == 1)
        {
            Diff.text = "Easy";
            DiffDMG.text = "Troop Damage: 2";
            DiffRes.text = "Resource Gain: 12";
            DiffHealth.text = "Troop Health: 6";
        }
        if (DiffNum == 2)
        {
            Diff.text = "medium";
            DiffDMG.text = "Troop Damage: 1";
            DiffRes.text = "Resource Gain: 10";
            DiffHealth.text = "Troop Health: 5";
        }
        if (DiffNum == 3)
        {
            Diff.text = "hard";
            DiffDMG.text = "Troop Damage: 1";
            DiffRes.text = "Resource Gain: 8";
            DiffHealth.text = "Troop Health: 4";
        }
    }
}
