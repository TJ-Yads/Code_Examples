﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PopulationManager : MonoBehaviour
{
    private TJGameController gamecontroller;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
        gamecontroller.CurrentPopulation += 1;
        gamecontroller.UpdatePopulation();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
