﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParentBinder : MonoBehaviour
{
    public GameObject Parent, Child;
    public string Tag;
    // Start is called before the first frame update
    void Start()
    {
        Parent = GameObject.FindWithTag(Tag);
        Child.transform.parent = Parent.transform;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
