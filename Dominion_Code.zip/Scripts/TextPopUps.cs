﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextPopUps : MonoBehaviour
{
    public GameObject TextPopUp;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void ShowText()
    {
        TextPopUp.SetActive(true);
    }
    public void TextFollower()
    {
        TextPopUp.transform.localPosition = Input.mousePosition;
    }
    public void HideText()
    {
        TextPopUp.SetActive(false);
    }
}
