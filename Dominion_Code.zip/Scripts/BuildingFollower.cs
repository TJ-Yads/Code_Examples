﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingFollower : MonoBehaviour
{
    private TJGameController gamecontroller;
    public GameObject BuildingEmpty, Building, BuildingGreen, BuildingRed;
    public Transform ObjSize;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
        gamecontroller.PlacingBuilding = true;
    }

    // Update is called once per frame
    void Update()
    {
        BuildingEmpty.transform.position = gamecontroller.HitEnd;
        if (Input.GetButtonUp("Fire1") && gamecontroller.hit.transform.tag == "Floor")
        {
            gamecontroller.PlacingBuilding = false;
            Destroy(gameObject);
            Instantiate(Building, gamecontroller.Buildable.transform);
        }
        if (Input.GetButtonUp("Fire2"))
        {
            gamecontroller.PlacingBuilding = false;
            Destroy(gameObject);
        }
        if (gamecontroller.hit.transform.tag != "Floor")
        {
            BuildingGreen.SetActive(false);
            BuildingRed.SetActive(true);
        }
        else
        {
            BuildingGreen.SetActive(true);
            BuildingRed.SetActive(false);
        }
    }
}
