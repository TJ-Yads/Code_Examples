﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject Credits, Menu, Difficulty, GameMenu, ControlsMenu;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void ChangeScene(int sceneNumber)
    {
        SceneManager.LoadScene(sceneNumber);
        Time.timeScale = 1;
    }
    public void ShowCredits()
    {
        Credits.SetActive(true);
        Menu.SetActive(false);
    }
    public void HideCredits()
    {
        Credits.SetActive(false);
        Menu.SetActive(true);
    }
    public void ShowControls()
    {
        ControlsMenu.SetActive(true);
        Menu.SetActive(false);
    }
    public void HideControls()
    {
        ControlsMenu.SetActive(false);
        Menu.SetActive(true);
    }
    public void ShowDifficulty()
    {
        Difficulty.SetActive(true);
        Menu.SetActive(false);
    }
    public void HideDifficulty()
    {
        Difficulty.SetActive(false);
        Menu.SetActive(true);
    }
    public void Quit()
    {
        Application.Quit();
    }
    public void PauseGame()
    {
        GameMenu.SetActive(true);
        Time.timeScale = 0;
    }
    public void ResumeGame()
    {
        GameMenu.SetActive(false);
        Time.timeScale = 1;
    }
}
