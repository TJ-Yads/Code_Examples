﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CastleMechanics : MonoBehaviour
{
    public GameObject BuildableEmpty, TextPopUp;
    private TJGameController gamecontroller;
    private ResourceCost CostList;
    public int Health;
    public Text BuildingHealth;
    private DifficultyManager DifficultyOBJ;
    // Start is called before the first frame update
    void Start()
    {
        GameObject DiffcultlyOject = GameObject.FindWithTag("Difficulty");
        DifficultyOBJ = DiffcultlyOject.GetComponent<DifficultyManager>();
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
        CostList = gameControllerObject.GetComponent<ResourceCost>();
        if (DifficultyOBJ.DifficultyValue == 3)
        {
            Health = Health - 5;
        }
    }

    // Update is called once per frame
    void Update()
    {
        BuildingHealth.text = "Castle health: " + Health;
        if (gamecontroller.CaslteButtons.activeInHierarchy == true)
        {
            gamecontroller.BuildingHealth.text = "Health: " + Health;
            gamecontroller.BuildingInfo.text = "This building allows for the construction of other buildings.";
        }
        if (Health <= 0)
        {
            gamecontroller.GameOver = true;
        }
    }
    public void BuildBarracks(GameObject BuildingName)
    {
        CostList.BarracksCost();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
    public void BuildFarm(GameObject BuildingName)
    {
        CostList.FarmCost();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
    public void BuildMill(GameObject BuildingName)
    {
        CostList.Mill();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
    public void BuildRC(GameObject BuildingName)
    {
        CostList.ResearchCenterCost();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
    public void BuildLY(GameObject BuildingName)
    {
        CostList.LumberYardCost();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
    public void BuildMC(GameObject BuildingName)
    {
        CostList.MiningCampCost();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
    public void BuildWT(GameObject BuildingName)
    {
        CostList.WatchtowerCost();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
    public void BuildHouse(GameObject BuildingName)
    {
        CostList.HouseCost();
        if (gamecontroller.wood >= CostList.Wood && gamecontroller.stone >= CostList.Stone && gamecontroller.gold >= CostList.Gold && gamecontroller.food >= CostList.Food)
        {
            gamecontroller.wood -= CostList.Wood;
            gamecontroller.stone -= CostList.Stone;
            gamecontroller.gold -= CostList.Gold;
            gamecontroller.food -= CostList.Food;
            BuildableEmpty = BuildingName;
            Instantiate(BuildableEmpty, gamecontroller.Buildable.transform);
            gamecontroller.ClearButtons();
            gamecontroller.UpdateResources();
        }
    }
}
