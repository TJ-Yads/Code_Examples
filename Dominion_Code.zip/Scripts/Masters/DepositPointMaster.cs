﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DepositPointMaster : MonoBehaviour
{
    private TJGameController gamecontroller;
    private DepositPointMechanics Child;
    public GameObject ActiveBuilding;
    public int LumberCount, MiningCount, MillCount;
    public bool HealthIncreased, LumberActive, MiningActive, MillActive, StoreHouseUpgraded;
    public GameObject HealthButton;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (ActiveBuilding != null && gamecontroller.DepositButtons.activeInHierarchy == true)
        {
            GameObject TargetedHouse = ActiveBuilding;
            Child = TargetedHouse.GetComponent<DepositPointMechanics>();
            gamecontroller.BuildingInfo.text = "This building increases your total " + Child.ResourceType + " capcity by " + Child.StorageBonus + ".";
        }
        if (StoreHouseUpgraded == false)
        {
            HealthButton.SetActive(true);
        }
        else
            HealthButton.SetActive(false);
    }
    public void SellBuilding()
    {
        if (LumberActive == true)
        {
            LumberCount -= 1;
            gamecontroller.gold += 5;
            gamecontroller.stone += 10;
            gamecontroller.food += 5;
        }
        if (MiningActive == true)
        {
            MiningCount -= 1;
            gamecontroller.wood += 10;
            gamecontroller.food += 10;
        }
        if (MillActive == true)
        {
            MillCount -= 1;
            gamecontroller.stone += 10;
            gamecontroller.wood += 10;
        }
        if (StoreHouseUpgraded == true)
        {
            if (LumberActive == true)
            {
                LumberCount -= 1;
            }
            if (MiningActive == true)
            {
                MiningCount -= 1;
            }
            if (MillActive == true)
            {
                MillCount -= 1;
            }
        }
        Destroy(ActiveBuilding);
        gamecontroller.ClearButtons();
        gamecontroller.UpdateResources();
    }

    public void IncreaseHealth()
    {
        if (HealthIncreased == false)
        {
            GameObject TargetedHouse = ActiveBuilding;
            //Child = TargetedHouse.GetComponent<HouseMechanics>();
            Child.HealthUp();
        }
        HealthIncreased = true;
    }
    public void UpgradeCapcity()
    {
        if (StoreHouseUpgraded == false && gamecontroller.wood > 15 && gamecontroller.stone > 15 && gamecontroller.gold > 15)
        {
            gamecontroller.wood -= 15;
            gamecontroller.stone -= 15;
            gamecontroller.gold -= 15;
            StoreHouseUpgraded = true;
            Child.StorageUp();
            gamecontroller.UpdateResources();
        }
    }
    public void UpdateCapacity()
    {
        gamecontroller.LumberCount = LumberCount;
        gamecontroller.MiningCount = MiningCount;
        gamecontroller.MillCount = MillCount;
        gamecontroller.UpdateResources();
    }
}
