﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoreHouseMaster : MonoBehaviour
{
    private TJGameController gamecontroller;
    private StoreHouseMechanics Child;
    public GameObject ActiveBuilding;
    public int StoreHouseCount;
    public bool StoreHouseUpgraded, HealthIncreased;
    public GameObject UpgradeButton;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (ActiveBuilding != null && gamecontroller.SHouseButtons.activeInHierarchy == true)
        {
            GameObject TargetedHouse = ActiveBuilding;
            Child = TargetedHouse.GetComponent<StoreHouseMechanics>();
            gamecontroller.BuildingHealth.text = "Health: " + Child.Health;
            gamecontroller.BuildingInfo.text = "This building increases your total resource capcity by " + Child.TotalBonus + ".";
        }
        gamecontroller.StorehouseCount = StoreHouseCount;
        if (StoreHouseUpgraded == false)
        {
            UpgradeButton.SetActive(true);
        }
        else
            UpgradeButton.SetActive(false);
    }
    public void SellBuilding()
    {
        gamecontroller.wood += 10;
        gamecontroller.stone += 10;
        gamecontroller.gold += 10;
        gamecontroller.food += 10;
        StoreHouseCount -= 1;
        if (StoreHouseUpgraded == true)
        {
            StoreHouseCount -= 1;
            StoreHouseUpgraded = false;
        }
        Destroy(ActiveBuilding);
        gamecontroller.ClearButtons();
    }
    public void UpgradeCapcity()
    {
        if (StoreHouseUpgraded == false && gamecontroller.wood > 15 && gamecontroller.stone > 15)
        {
            gamecontroller.wood -= 15;
            gamecontroller.stone -= 15;
            StoreHouseUpgraded = true;
            Child.StorageUp();
        }
    }
    public void IncreaseHealth()
    {
        if (HealthIncreased == false)
        {
            Child.HealthUp();
        }
        HealthIncreased = true;
    }
}
