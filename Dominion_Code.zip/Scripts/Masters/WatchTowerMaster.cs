﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WatchTowerMaster : MonoBehaviour
{
    private TJGameController gamecontroller;
    public GameObject ActiveBuilding;
    private WatchTowerMechanics Child;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (ActiveBuilding != null && gamecontroller.WTButtons.activeInHierarchy == true)
        {
            GameObject TargetedHouse = ActiveBuilding;
            Child = TargetedHouse.GetComponent<WatchTowerMechanics>();
            //gamecontroller.BuildingHealth.text = "Health: " + Child.Health;
            gamecontroller.BuildingInfo.text = "This building fires arrows at neaby enemies.";
        }
    }
    public void SellBuilding()
    {
        gamecontroller.wood += 30;
        gamecontroller.stone += 10;
        gamecontroller.gold += 10;
        gamecontroller.food += 10;
        Destroy(ActiveBuilding);
        gamecontroller.ClearButtons();
        gamecontroller.UpdateResources();
    }
}
