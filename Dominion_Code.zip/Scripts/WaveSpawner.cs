﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveSpawner : MonoBehaviour
{
    private TJGameController gamecontroller;
    public Transform EnemySpawn;
    public GameObject Soldier, Archer, Cavarly;
    public int SoldierCount, ArcherCount, CavarlyCount;
    public float startWait, spawnWait, waveWait;
    public int waveTotal = 1;
    public Transform SpawnPosition;
    public bool ArchActive, CavActive;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Waves());
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public IEnumerator Waves()
    {
        yield return new WaitForSeconds(startWait);
        gamecontroller.WaveValue += 1;
        gamecontroller.UpdateWave();
        while (true)
        {
            for (int i = 0; i < SoldierCount; i++)
            {
                Instantiate(Soldier, SpawnPosition.position, SpawnPosition.rotation);
                if (ArchActive == true)
                {
                    Instantiate(Archer, SpawnPosition.position, SpawnPosition.rotation);
                }
                if (CavActive == true)
                {
                    Instantiate(Cavarly, SpawnPosition.position, SpawnPosition.rotation);
                }
                yield return new WaitForSeconds(spawnWait);
            }
            yield return new WaitForSeconds(waveWait);
            WaveIncrease();
        }
    }
    public void WaveIncrease()
    {
        gamecontroller.UpdateWave();
        waveTotal += 1;
        SoldierCount += (1 * waveTotal) - 1;
        if (waveTotal >= 5)
        {
            ArchActive = true;
            ArcherCount += (1 * waveTotal) - 3;
        }
        if (waveTotal >= 10)
        {
            CavActive = true;
            CavarlyCount += (1 * waveTotal) - 8;
        }
    }
}
