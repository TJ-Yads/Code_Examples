﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WatchTowerFiring : MonoBehaviour
{
    public GameObject Projectile, closestEnemy;
    public Transform ProjectileSpawn;
    public int Health;
    public float AttackSpeed, nextHit;
    public GameObject[] Enemies;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Enemies = GameObject.FindGameObjectsWithTag("Enemy");
        float enemyDistance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject enemy in Enemies)
        {
            Vector3 diff = enemy.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < enemyDistance && enemy.GetComponent<EnemyController>().isTarget == false)
            {
                closestEnemy = enemy;
                enemyDistance = curDistance;
            }
        }
        if (closestEnemy != null)
        {
            ProjectileSpawn.transform.LookAt(closestEnemy.transform);
        }

        if (Health <= 0)
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "Enemy")
        {
            if (Time.time > nextHit)
            {
                Debug.Log("fired");
                Instantiate(Projectile, ProjectileSpawn.position, ProjectileSpawn.rotation);
                nextHit = Time.time + AttackSpeed;
            }
        }
    }
}
