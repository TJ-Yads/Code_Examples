﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DepositPointMechanics : MonoBehaviour
{
    private DepositPointMaster DepositController;
    public GameObject Building, BuildingRime;
    public bool IncreasedStorage, IncreasedHealth;
    public int Health, StorageBonus = 200;
    public bool Wood, Stone, Food, Starter;
    public string ResourceType;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("MasterBuilding");
        DepositController = gameControllerObject.GetComponent<DepositPointMaster>();
        if (Starter == false)
        {
            if (Wood == true)
            {
                DepositController.LumberCount += 1;
            }
            if (Stone == true)
            {
                DepositController.MiningCount += 1;
            }
            if (Food == true)
            {
                DepositController.MillCount += 1;
            }
            DepositController.UpdateCapacity();
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Health <= 0)
        {
            if (Wood == true)
            {
                DepositController.LumberCount -= 1;
            }
            if (Stone == true)
            {
                DepositController.MiningCount -= 1;
            }
            if (Food == true)
            {
                DepositController.MillCount -= 1;
            }
            Destroy(gameObject);
        }
    }
    public void HealthUp()
    {
        Health = Health * 2;
        IncreasedHealth = true;
    }
    public void StorageUp()
    {
        if (Wood == true)
        {
            DepositController.LumberCount += 1;
        }
        if (Stone == true)
        {
            DepositController.MiningCount += 1;
        }
        if (Food == true)
        {
            DepositController.MillCount += 1;
        }
        IncreasedStorage = true;
        StorageBonus = 400;
        DepositController.UpdateCapacity();
    }
}
