﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResearchMechanics : MonoBehaviour
{
    private TJGameController gamecontroller;
    public GameObject Building, BuildingRime;
    public int Health;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<TJGameController>();
        gamecontroller.ActiveResearchBuild = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (Health <= 0)
        {
            Destroy(gameObject);
        }
    }
}
