﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoreHouseMechanics : MonoBehaviour
{
    private StoreHouseMaster SHouseController;
    public GameObject Building, BuildingRime;
    public bool IncreasedStorage, IncreasedHealth;
    public int Health, TotalBonus;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("SHouseMaster");
        SHouseController = gameControllerObject.GetComponent<StoreHouseMaster>();
        SHouseController.StoreHouseCount += 1;
        TotalBonus = 1000;
    }

    // Update is called once per frame
    void Update()
    {
        if (Health <= 0)
        {
            SHouseController.StoreHouseCount -= 1;
            if (IncreasedStorage == true)
            {
                SHouseController.StoreHouseCount -= 1;
            }
            Destroy(gameObject);
        }
    }
    public void StorageUp()
    {
        SHouseController.StoreHouseCount += 1;
        IncreasedStorage = true;
        TotalBonus += 1000;
    }
    public void HealthUp()
    {
        Health = Health * 2;
        IncreasedHealth = true;
    }
}
