﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarracksSpawnPoint : MonoBehaviour
{
    public GameObject Building, BuildingRime;
    public Transform SpawnPoint;
    private BarracksMechanics BarracksController;
    public int TroopUnlock;
    public int Health;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("BarracksMaster");
        BarracksController = gameControllerObject.GetComponent<BarracksMechanics>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Health <= 0)
        {
            Destroy(gameObject);
        }
    }
    public void TroopUnlocked()
    {
        BarracksController.TroopUnlock += 1;
    }
}
