﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HouseMechanics : MonoBehaviour
{
    private HouseMaster HouseController;
    public GameObject Building, BuildingRime;
    public Transform SpawnPoint;
    public bool IncreasedStorage, IncreasedHealth;
    public int Health, TotalPopBonus;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("HouseMaster");
        HouseController = gameControllerObject.GetComponent<HouseMaster>();
        HouseController.HouseCount += 1;
        TotalPopBonus = 5;
        HouseController.PopulationUpdater();
    }

    // Update is called once per frame
    void Update()
    {
        if (Health <= 0)
        {
            HouseController.HouseCount -= 1;
            if (IncreasedStorage == true)
            {
                HouseController.HouseCount -= 1;
            }
            Destroy(gameObject);
        }
    }
    public void CapacityUp()
    {
        HouseController.HouseCount += 1;
        IncreasedStorage = true;
        TotalPopBonus += 5;
        HouseController.PopulationUpdater();
    }
    public void HealthUp()
    {
        Health = Health * 2;
        IncreasedHealth = true;
    }
}
