﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransition : MonoBehaviour
{
    private GameController gamecontroller;
    public AndrewController pc;
    public Rigidbody2D pcRB;
    public int SceneNumber;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<GameController>();
        pc = GameObject.FindGameObjectWithTag("Player").GetComponent<AndrewController>();
        pcRB = pc.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (SceneNumber == 2)
        {
            gamecontroller.returning = false;
            gamecontroller.gameAud.Pause();
            gamecontroller.gameAud.clip = gamecontroller.pondTheme;
            gamecontroller.gameAud.Play();
            gamecontroller.outHub = true;
            gamecontroller.DoorNumber = 2;
            gamecontroller.sceneNumber = 1;
            // StartCoroutine(gamecontroller.BlackOut());
        }
        if (SceneNumber == 4)
        {
            gamecontroller.returning = false;
            gamecontroller.gameAud.Pause();
            gamecontroller.gameAud.clip = gamecontroller.canyonTheme;
            gamecontroller.gameAud.Play();
            gamecontroller.outHub = true;
            gamecontroller.DoorNumber = 4;
            gamecontroller.sceneNumber = 3;
            // StartCoroutine(gamecontroller.BlackOut());
        }
        if (SceneNumber == 5)
        {
            gamecontroller.returning = false;
            gamecontroller.gameAud.Pause();
            gamecontroller.gameAud.clip = gamecontroller.beachTheme;
            gamecontroller.gameAud.Play();
            gamecontroller.outHub = true;
            gamecontroller.DoorNumber = 5;
            gamecontroller.sceneNumber = 4;
            // StartCoroutine(gamecontroller.BlackOut());
        }
        if (SceneNumber == 3)
        {
          //  Debug.Log("Jungle");
            gamecontroller.gameAud.Pause();
            gamecontroller.gameAud.clip = gamecontroller.jungleTheme;
            gamecontroller.gameAud.Play();
            gamecontroller.outHub = true;
            gamecontroller.DoorNumber = 3;
            gamecontroller.sceneNumber = 2;
            // StartCoroutine(gamecontroller.BlackOut());
        }
        if (SceneNumber == 1)
        {
            gamecontroller.gameAud.Pause();
            gamecontroller.gameAud.clip = gamecontroller.hubTheme;
            gamecontroller.gameAud.Play();
            gamecontroller.outHub = false;
            gamecontroller.sceneNumber = 0;
            // gamecontroller.returning = true;

            if (pc.duckTamed == true)
            {
                gamecontroller.duckTamed = true;
            }
            if (pc.frogTamed == true)
            {
                gamecontroller.frogTamed = true;
            }
            if (pc.horseTamed == true)
            {
                gamecontroller.horseTamed = true;
            }
            if (pc.catTamed == true)
            {
                gamecontroller.CatTamed = true;
            }
            if (pc.sharkTamed == true)
            {
                gamecontroller.SharkTamed = true;
            }
            if (pc.buffoTamed == true)
            {
                gamecontroller.BuffoTamed = true;
            }
            if (pc.monkeyTamed == true)
            {
                gamecontroller.MonkeyTamed = true;
            }
            if (pc.snakeTamed == true)
            {
                gamecontroller.SnakeTamed = true;
            }
            if (pc.dogTamed == true)
            {
                gamecontroller.DogTamed = true;
            }
            //StartCoroutine(gamecontroller.BlackOut());
        }
        gamecontroller.ChangeScene(SceneNumber);

    }
}

