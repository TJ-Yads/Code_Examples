﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HubStartUp : MonoBehaviour
{
    public GameObject Player, Vis;
    public Transform[] SpawnPoints;
    private GameController gamecontroller;
    // Start is called before the first frame update
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gamecontroller = gameControllerObject.GetComponent<GameController>();
        if (gamecontroller.DoorNumber == 1)
        {
            Player.transform.position = SpawnPoints[0].position;
            Vis.transform.position = SpawnPoints[1].position;
        }
        else if (gamecontroller.DoorNumber == 2)
        {
            Player.transform.position = SpawnPoints[2].position;
            Vis.transform.position = SpawnPoints[3].position;
        }
        else if (gamecontroller.DoorNumber == 3)
        {
            Player.transform.position = SpawnPoints[4].position;
            Vis.transform.position = SpawnPoints[5].position;
        }
        else if (gamecontroller.DoorNumber == 4)
        {
            Player.transform.position = SpawnPoints[6].position;
            Vis.transform.position = SpawnPoints[7].position;
        }
        else if (gamecontroller.DoorNumber == 5)
        {
            Player.transform.position = SpawnPoints[8].position;
            Vis.transform.position = SpawnPoints[9].position;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
