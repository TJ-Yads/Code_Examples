﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponUnlockPUP : MonoBehaviour
{
    private CMF.CameraController CameraController;
    public GameObject WeaponCard;
    private GameObject UITransform;
    private void Start()
    {
        GameObject playerControllerObject = GameObject.FindWithTag("Player");
        CameraController = playerControllerObject.GetComponentInChildren<CMF.CameraController>();
        UITransform = GameObject.FindWithTag("CardTarget");
    }
    // Update is called once per frame
    void Update()
    {
        transform.Rotate(new Vector3(0, -75, 0) * Time.deltaTime);
    }
    //unlocks a weapon in the wheel can also be used for ability unlocking
    public int WeaponNum;
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Instantiate(WeaponCard, UITransform.transform.position, UITransform.transform.rotation);
            CameraController.enabled = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            Time.timeScale = 0;
            GameObject Player = other.gameObject;
            PlayerController HitReact = Player.GetComponent<PlayerController>();
            HitReact.UnlockWeapon(WeaponNum);
            Destroy(gameObject);
        }
    }
}
