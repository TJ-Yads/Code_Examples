﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickupMover : MonoBehaviour
{
    public float Speed;
    public Collider PhysicalCollide;
    private Vector3 Tag;
    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "Player")
        {
            Tag = other.transform.position;
            StartCoroutine(MoveToPlayer());
        }
    }
    IEnumerator MoveToPlayer()
    {
        yield return new WaitForSeconds(.4f);
        PhysicalCollide.isTrigger = true;
        Vector3 Target = Tag;
        float TrueSpeed = Speed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, Target, TrueSpeed);
        Destroy(gameObject, 3f);
    }
}
