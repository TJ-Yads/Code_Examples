﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPUP : MonoBehaviour
{
    //once touched by the player it provides 20 health
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            GameObject Player = other.gameObject;
            PlayerHealth HitReact = Player.GetComponent<PlayerHealth>();
            HitReact.RestoreHealth();
            Destroy(gameObject);
        }
    }
}
