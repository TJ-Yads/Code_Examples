﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoPUP : MonoBehaviour
{
    public bool Specific;
    private int WeaponNum;
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            if (Specific)
            {
                WeaponNum = Random.Range(0, 7);
                GameObject Player = other.gameObject;
                PlayerController HitReact = Player.GetComponent<PlayerController>();
                HitReact.AmmoSpecific(WeaponNum);
            }
            else
            {
                GameObject Player = other.gameObject;
                PlayerController HitReact = Player.GetComponent<PlayerController>();
                HitReact.ReplenishAmmo();
            }
            Destroy(gameObject);
        }
    }
}
