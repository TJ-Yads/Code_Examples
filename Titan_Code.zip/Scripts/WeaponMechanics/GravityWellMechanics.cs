﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class GravityWellMechanics : MonoBehaviour
{
    //the gravity well pulls nearby enemies into it and disables nav mesh and kinematics while active
    private Rigidbody rb;
    private List<GameObject> EnemyList = new List<GameObject>();
    public float pullForce = 1;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.AddForce(transform.forward * 25, ForceMode.Impulse);
        rb.AddForce(transform.up * 3, ForceMode.Impulse);
        StartCoroutine(Gravity());
    }

    // Update is called once per frame
    void Update()
    {
        Destroy(gameObject, 7f);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy")
        {
            GameObject EnemyHit = other.gameObject;
            EnemyList.Add(EnemyHit);
        }
    }
    IEnumerator Gravity()
    {
        //while active it will pull enemies that are a part of enemy list
        while (true)
        {
            foreach (GameObject Enemy in EnemyList)
            {
                Enemy.GetComponent<NavMeshAgent>().enabled = false;
                Enemy.GetComponent<Rigidbody>().isKinematic = false;
                Enemy.GetComponent<EnemyPhysicsFixer>().NoPhysics = true;
                Vector3 forceDirection = transform.position - Enemy.transform.position;
                Rigidbody RBE = Enemy.GetComponent<Rigidbody>();
                RBE.AddForce(forceDirection.normalized * pullForce);
                //Vector3 Target = gameObject.transform.position;
                //Enemy.transform.position = Vector3.MoveTowards(transform.position, Target, 1);
            }
            yield return new WaitForSeconds(.35f);
        }
    }
}
