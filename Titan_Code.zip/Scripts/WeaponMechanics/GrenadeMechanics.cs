﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrenadeMechanics : MonoBehaviour
{
    public Rigidbody rb;
    public GameObject NadeExplode;
    public Transform ExplodeLoc;
    // Start is called before the first frame update
    void Start()
    {

        rb = GetComponent<Rigidbody>();
        rb.AddForce(transform.forward * 18, ForceMode.Impulse);
        rb.AddForce(transform.up * 7, ForceMode.Impulse);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "enemyHealth")
        {
            Instantiate(NadeExplode, ExplodeLoc.position, ExplodeLoc.rotation);
            Destroy(gameObject);
        }
        if (other.tag == "ENV_OBJ")
        {
            StartCoroutine(Grenade(3f));
        }
        StartCoroutine(Grenade(8f));
    }
    IEnumerator Grenade(float Timer)
    {
        yield return new WaitForSeconds(3f);
        Instantiate(NadeExplode, ExplodeLoc.position, ExplodeLoc.rotation);
        Destroy(gameObject);
    }
}
