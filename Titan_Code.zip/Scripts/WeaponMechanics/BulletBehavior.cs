﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehavior : MonoBehaviour
{
    public GameObject hitFX;
    public GameObject explosionFX;
    public GameObject Bomb;
    public Transform FXSpawn;
    public float shotForce, MaxAc, MinAc;

    //values used for bullet movement
    public float speed;
    private Rigidbody rb;

    //DMGVal is the damage each pellet will do to enemies while the bools allow a bullet to freeze or burn enemies and explosive allows the rocket to spawn a explosion
    public float DMGVal;
    public bool Frost, Fire, Explosive;

    private float AccuracyX, AccuracyY;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            AccuracyX = Random.Range(MinAc, MaxAc);
            AccuracyY = Random.Range(MinAc, MaxAc);
            transform.Rotate(AccuracyX, AccuracyY, 0);
            rb.AddForce(transform.forward * shotForce, ForceMode.VelocityChange);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "ENV_OBJ")
        {
            DestroySelf();
        }
        if (other.tag == "enemyHealth")
        {
            Instantiate(explosionFX, FXSpawn.position, transform.rotation);
            Instantiate(hitFX, FXSpawn.position, transform.rotation);
            GameObject EnemyHit = other.gameObject;
            EnemyHealth HitReact = EnemyHit.GetComponentInChildren<EnemyHealth>();
            if (Frost)
            {
                HitReact.Frozen = true;
            }
            if (Fire)
            {
                HitReact.Burned = true;
            }
            if (Explosive)
            {
                Instantiate(Bomb, transform.position, transform.rotation);
            }
            HitReact.Hurt(DMGVal);
            gameObject.SetActive(false);
        }
    }
    public void DestroySelf()
    {
        Instantiate(explosionFX, FXSpawn.position, transform.rotation);
        Instantiate(hitFX, FXSpawn.position, transform.rotation);
        if (Explosive)
        {
            Instantiate(Bomb, transform.position, transform.rotation);
        }
        gameObject.SetActive(false);
    }
}
