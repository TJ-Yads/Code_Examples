﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombBehavior : MonoBehaviour
{
    //script is used for explosives and allows it to hit enemies and destroy itself
    public float DMGVal;
    public int PlayerDMG;
    // Update is called once per frame
    void Update()
    {
        Destroy(gameObject, .5f);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "enemyHealth")
        {
            GameObject EnemyHit = other.gameObject;
            EnemyHealth HitReact = EnemyHit.GetComponentInChildren<EnemyHealth>();
            HitReact.Hurt(DMGVal);
        }
        if (other.tag == "Player")
        {
            GameObject PlayerHit = other.gameObject;
            PlayerHealth HitReact = PlayerHit.GetComponentInChildren<PlayerHealth>();
            HitReact.TakingDMG(PlayerDMG);
        }
    }
}
