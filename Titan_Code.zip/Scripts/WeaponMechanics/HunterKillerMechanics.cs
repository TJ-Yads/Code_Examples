﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HunterKillerMechanics : MonoBehaviour
{
    private Rigidbody rb;
    private List<GameObject> EnemyList = new List<GameObject>();
    private GameObject FarthestEnemy;
    private float TargetVal = 0;
    public GameObject Explosion;
    public Transform ExplodeSpawn;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.AddForce(transform.forward * 2, ForceMode.Impulse);
        rb.AddForce(transform.up * 25, ForceMode.Impulse);
        StartCoroutine(Hunt());
    }

    // Update is called once per frame
    void Update()
    {
        if (FarthestEnemy != null)
        {
            Vector3 Target = FarthestEnemy.transform.position;
            gameObject.transform.position = Vector3.MoveTowards(transform.position, Target, 1.5f);
            if (Vector3.Distance(transform.position, FarthestEnemy.transform.position) < 1)
            {
                Instantiate(Explosion, ExplodeSpawn.position, ExplodeSpawn.rotation);
                Destroy(gameObject);
            }
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy")
        {
            GameObject EnemyHit = other.gameObject;
            EnemyList.Add(EnemyHit);
        }
    }
    IEnumerator Hunt()
    {
        yield return new WaitForSeconds(.5f);
        Vector3 position = transform.position;
        foreach (GameObject Enemy in EnemyList)
        {
            //checks each enemy in the list and creates a distance value for them if the enemies distance it higher then the target value
            //then the farthest marked enemy is marked as the current farthest enemy
            Vector3 Distance = Enemy.transform.position - position;
            float CurrentDis = Distance.sqrMagnitude;
            if (CurrentDis > TargetVal)
            {
                FarthestEnemy = Enemy;
                TargetVal = CurrentDis;
            }
        }
    }
}
