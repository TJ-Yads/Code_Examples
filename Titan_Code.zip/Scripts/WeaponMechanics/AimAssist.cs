﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimAssist : MonoBehaviour
{
    public float shotForce, MaxAc, MinAc;
    private Rigidbody rb;
    public float Speed1, Speed2;
    private float AccuracyX, AccuracyY;
    private void Start()
    {
        AccuracyX = Random.Range(MinAc, MaxAc);
        AccuracyY = Random.Range(MinAc, MaxAc);
        transform.Rotate(AccuracyX, AccuracyY, 0);
        rb = GetComponent<Rigidbody>();
        rb.AddForce(transform.forward * shotForce, ForceMode.VelocityChange);
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "Enemy")
        {
            GameObject Enemy = other.gameObject;
            transform.position = Vector3.RotateTowards(transform.position, other.transform.position, Speed1, Speed2);
        }
    }
}
