﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCullDistances : MonoBehaviour
{
    public float LightRange, SmallOBJRange, LargeOBJRange, EnemyRange;
    // Start is called before the first frame update
    void Start()
    {
        Camera camera = GetComponent<Camera>();
        float[] distances = new float[32];
        camera.layerCullSpherical = true;
        distances[10] = LightRange;
        distances[9] = EnemyRange;
        distances[11] = LargeOBJRange;
        distances[14] = SmallOBJRange;
        camera.layerCullDistances = distances;
    }
}
