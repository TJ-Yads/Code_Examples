﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimController : MonoBehaviour
{
    public Animator anim;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.W))
        {
            anim.SetBool("isWalking", true);
        }
        if (Input.GetKeyUp(KeyCode.W))
        {
            anim.SetBool("isWalking", false);
        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            anim.SetBool("isWalkingBack", true);
        }
        if (Input.GetKeyUp(KeyCode.S))
        {
            anim.SetBool("isWalkingBack", false);
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            anim.SetBool("isWalkingSide1", true);
        }
        if (Input.GetKeyUp(KeyCode.A))
        {
            anim.SetBool("isWalkingSide1", false);
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            anim.SetBool("isWalkingSide1", true);
        }
        if (Input.GetKeyUp(KeyCode.D))
        {
            anim.SetBool("isWalkingSide1", false);
        }





        if (Input.GetKeyDown(KeyCode.Space))
        {
            anim.SetTrigger("playerJump");
        }
        if (Input.GetKeyUp(KeyCode.Space))
        {
            anim.SetTrigger("backToIdle");
        }


        if (Input.GetKeyDown(KeyCode.Q))
        {
            anim.SetTrigger("weaponSwap");
        }
        if (Input.GetKeyUp(KeyCode.Q))
        {
            anim.SetTrigger("backToIdle");
        }



        if (Input.GetKeyDown(KeyCode.C))
        {
            anim.SetTrigger("playerGrenade");
        }
        if (Input.GetKeyUp(KeyCode.C))
        {
            anim.SetTrigger("backToIdle");
        }



        if (Input.GetKeyDown(KeyCode.LeftAlt))
        {
            anim.SetTrigger("playerDodge");
        }
        if (Input.GetKeyUp(KeyCode.LeftAlt))
        {
            anim.SetTrigger("backToIdle");
        }
    }
}
