﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimType : MonoBehaviour
{
    public GameObject p1;
    public GameObject p2;

    //public GameObject aimHere;
    //public GameObject aimHere2;

    void Update()
    {
        //if (Input.GetKeyDown(KeyCode.Mouse1))
        //{
        //    p2.transform.position = aimHere.transform.position;
        //    p2.transform.rotation = aimHere.transform.rotation;
        //}
        //if (Input.GetKeyUp(KeyCode.Mouse1))
        //{
        //    p1.transform.position = aimHere2.transform.position;
        //    p1.transform.rotation = aimHere2.transform.rotation;
        //}
        if (Input.GetKey(KeyCode.Mouse1))
        {
            p1.SetActive(false);
            p2.SetActive(true);
            //by setting the p1 postion equal to p2 and vice versa the player objects will always be at the same location
            p1.transform.position = p2.transform.position;
            p1.transform.rotation = p2.transform.rotation;
        }
        else
        {
            p1.SetActive(true);
            p2.SetActive(false);
            p2.transform.position = p1.transform.position;
            p2.transform.rotation = p1.transform.rotation;
        }
    }
}
