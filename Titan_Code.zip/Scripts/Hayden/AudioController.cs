﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioController : MonoBehaviour
{
    public static bool playReload1;

    AudioSource audioSource;

    public AudioClip reload1;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (playReload1)
        {
            audioSource.PlayOneShot(reload1, .7f);
            playReload1 = false;
        }
    }
}
