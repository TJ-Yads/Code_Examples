﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    private bool Paused;
    public GameObject GameMenu;
    public GameObject[] ExtraMenus;
    public CMF.CameraController CameraController;
    void Start()
    {

    }

    private void Update()
    {
        if (Input.GetButtonDown("Cancel"))
        {
            Paused = !Paused;
            if (Paused == true)
            {
                CameraController.enabled = false;
                GameMenu.SetActive(true);
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                Time.timeScale = 0;
            }
            else
            {
                foreach (GameObject Menu in ExtraMenus)
                {
                    Menu.SetActive(false);
                }
                CameraController.enabled = true;
                GameMenu.SetActive(false);
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
                Time.timeScale = 1;
            }
        }
    }
}
