﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveStats : MonoBehaviour
{
    //this script holds and saves game stats such as kills or deaths
    public int Kills, Deaths;
    // Start is called before the first frame update
    void Start()
    {
        LoadStats();
    }
    //loads up previous stat lists and is done when starting the game or entering a scene
    public void LoadStats()
    {
        Kills = PlayerPrefs.GetInt("Kills");
        Deaths = PlayerPrefs.GetInt("Deaths");
    }
    //saves new stat data and is used  when the player dies or hits a checkpoint
    public void SaveNewStats()
    {
        PlayerPrefs.SetInt("Kills", Kills);
        PlayerPrefs.SetInt("Deaths", Deaths);
        PlayerPrefs.Save();
    }
}
