﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    //script used for player health and shields
    public float Health, Shield, MaxHealth, MaxShield, ShieldRate;
    public float ShieldDelay;
    private bool ShieldHurt, ShieldBlink, HealthBlink;
    public Text HealthTex, ShieldTex;
    public float ShieldCounter = 0;
    //data used for when the player dies
    private bool YouDied;
    public GameObject DeathMenu;
    //I is a counter variable for healing
    private int I = 0;
    //image items for the health and shield bars
    public Image HealthBar, ShieldBar;
    public GameObject ShieldIcon, ShieldBrokeIcon, HealthCriticalIcon;
    //item used for shield breaking
    public Transform FXSpawn;
    public GameObject BrokeShieldFX;
    //script used for saving stats
    private SaveStats StatSaver;
    //used to disable the camera movement on a menu
    public CMF.CameraController CameraController;
    // Start is called before the first frame update
    void Start()
    {
        Health = MaxHealth;
        Shield = MaxShield;
        HealthTex.text = "" + Health;
        ShieldTex.text = "" + Shield;
        HealthBar.fillAmount = Health / 100;
        ShieldBar.fillAmount = Shield / 100;
    }

    // Update is called once per frame
    void Update()
    {
        if (Shield > MaxShield)
        {
            Shield = MaxShield;
        }
        //once the counter is higher then delay regen will begin, counter is reset on taking damage
        if (Shield < MaxShield)
        {
            ShieldCounter += Time.deltaTime;
            if (ShieldCounter >= ShieldDelay)
            {
                ShieldCounter = 0;
                ShieldHurt = false;
                StartCoroutine(ShieldCharge());
            }
        }
    }
    //when activated so long as shieldhurt is false the player will regen there shield up to max
    public IEnumerator ShieldCharge()
    {
        StopCoroutine(ShieldBlinker());
        ShieldIcon.SetActive(true);
        ShieldBrokeIcon.SetActive(false);
        ShieldBlink = false;
        while (ShieldHurt == false && Shield < MaxShield)
        {
            Shield += ShieldRate;
            ShieldTex.text = "" + Shield;
            ShieldBar.fillAmount = Shield / 100;
            yield return new WaitForSeconds(.2f);
        }
    }
    //creates instances of damage based off the given int value and will hit shields first
    public void TakingDMG(int DMGVal)
    {
        if (Shield > 0)
        {
            Shield -= DMGVal;
            if (Shield < 0)
            {
                Shield = 0;
            }
        }
        else
        {
            Health -= DMGVal;
            if (Health == 0)
            {
                Health = 0;
            }
            if (Health <= MaxHealth * .33 && HealthBlink == false)
            {
                StartCoroutine(HealthBlinker());
            }
            if (Health < 0)
            {
                GameOver();
                Health = 0;
            }
        }
        if (Shield == 0 && ShieldBlink == false)
        {
            StartCoroutine(ShieldBlinker());
        }
        HealthTex.text = "" + Health;
        HealthBar.fillAmount = Health / 100;
        ShieldTex.text = "" + Shield;
        ShieldBar.fillAmount = Shield / 100;
        ShieldHurt = true;
        ShieldCounter = 0;
    }
    public void RestoreHealth()
    {
        StartCoroutine(Healing());
        if (Health <= MaxHealth - 20)
        {
            Health += 10;
        }
        else
        {
            Health += MaxHealth - Health;
        }
        HealthBar.fillAmount = Health / 100;
        HealthTex.text = "" + Health;
    }
    public IEnumerator Healing()
    {
        I = 0;
        while(I < 20)
        {
            Health += 1;
            if (Health >= MaxHealth)
            {
                Health = MaxHealth;
                I = 50;
            }
            yield return new WaitForSeconds(.5f);
            HealthTex.text = "" + Health;
            HealthBar.fillAmount = Health / 100;
            I += 1;
            if (Health > MaxHealth * .33)
            {
                HealthCriticalIcon.SetActive(false);
                HealthBlink = false;
            }
        }
    }
    public void GameOver()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        CameraController.enabled = false;
        GameObject GameController = GameObject.FindGameObjectWithTag("GameController");
        StatSaver = GameController.GetComponent<SaveStats>();
        StatSaver.Deaths += 1;
        StatSaver.SaveNewStats();
        Time.timeScale = 0;
        YouDied = true;
        DeathMenu.SetActive(true);
    }
    public IEnumerator ShieldBlinker()
    {
        Instantiate(BrokeShieldFX, FXSpawn.position, FXSpawn.rotation);
        ShieldBlink = true;
        ShieldIcon.SetActive(false);
        ShieldBrokeIcon.SetActive(true);
        yield return new WaitForSeconds(.5f);
        ShieldBrokeIcon.SetActive(false);
        yield return new WaitForSeconds(.5f);
        ShieldBrokeIcon.SetActive(true);
        yield return new WaitForSeconds(.5f);
        ShieldBrokeIcon.SetActive(false);
        yield return new WaitForSeconds(.5f);
        ShieldBrokeIcon.SetActive(true);
    }
    public IEnumerator HealthBlinker()
    {
        HealthBlink = true;
        HealthCriticalIcon.SetActive(true);
        yield return new WaitForSeconds(.5f);
        HealthCriticalIcon.SetActive(false);
        yield return new WaitForSeconds(.5f);
        HealthCriticalIcon.SetActive(true);
        yield return new WaitForSeconds(.5f);
        HealthCriticalIcon.SetActive(false);
        yield return new WaitForSeconds(.5f);
        HealthCriticalIcon.SetActive(true);
    }
}
