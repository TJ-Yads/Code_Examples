﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerAbilityController : MonoBehaviour
{
    private Rigidbody rb;
    public Transform AbilitySpawn;
    //all abilites use the cooldown feature while only some use a OBJ if it doesnt use an OBJ use [0]
    private float CurrentAbCoolDown;
    private GameObject CurrentAbOBJ;
    //cooldown order is heal, grenade, dash, hunterkiller and gravity well
    public float[] AbilityCooldowns;
    public GameObject[] AbilityOBJs;
    public int DodgePower;
    //data used for UI of active ability
    public string[] AbilityNames;
    public Text CurrentAbility;

    private bool OnCooldown, GrenadeDown, DodgeDown;
    private int LastAbility, ActiveAbility;
    public GameObject AbilityWheel, DodgeFullIcon, GrenadeFullIcon, AbilFullIcon;
    //used for UI of current ability
    public Sprite[] AbilityLogo;
    public Image CurrentLogo, DodgeVis, GrenadeVis, AbilityVis, AbilLogo2;

    //
    //Hayden
    public GameObject dashFX, HealFX;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        ChangeAbility(1);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(Time.timeScale > 0)
        {
            if (Input.GetButtonDown("UseAbility") && OnCooldown == false)
            {
                //
                //Hayden
                dashFX.SetActive(true);

                OnCooldown = true;
                //activates heal
                if (ActiveAbility == 1)
                {

                    StartCoroutine(HealingFX());
                }
                //activates dodge
                if (ActiveAbility == 3)
                {
                    rb.AddForce(rb.velocity.normalized * DodgePower, ForceMode.VelocityChange);
                }
                //throws other abilites like grenade, gravity or hunter
                else
                {
                    Instantiate(CurrentAbOBJ, AbilitySpawn.position, AbilitySpawn.rotation);
                }
                AbilityVis.fillAmount = 1;
                StartCoroutine(AbilityCooling());
            }
            if (Input.GetButtonDown("AbilitySwap"))
            {
                ChangeAbility(LastAbility);
            }
            if (Input.GetButtonDown("Grenade") && GrenadeDown == false)
            {
                GrenadeVis.fillAmount = 1;
                GrenadeDown = true;
                Instantiate(AbilityOBJs[1], AbilitySpawn.position, AbilitySpawn.rotation);
                StartCoroutine(GrenadeCooling());
            }
            if (Input.GetButtonDown("Dodge") && DodgeDown == false)
            {
                DodgeDown = true;
                DodgeVis.fillAmount = 1;
                rb.AddForce(rb.velocity * DodgePower,ForceMode.Impulse);
                StartCoroutine(DodgeCooling());
            }
        }
        //these functions while have a visual cooldown circle when said ability is used
        if (OnCooldown == true)
        {
            AbilFullIcon.SetActive(true);
            AbilityVis.fillAmount -= 100 / (CurrentAbCoolDown * 50) / 100;
        }
        if (DodgeDown == true)
        {
            DodgeFullIcon.SetActive(true);
            DodgeVis.fillAmount -= 100 / (AbilityCooldowns[2] * 50) / 100;
        }
        if (GrenadeDown == true)
        {
            GrenadeFullIcon.SetActive(true);
            GrenadeVis.fillAmount -= 100 / (AbilityCooldowns[1] * 50) / 100;
        }

        //
        //Hayden
        if (Input.GetButtonUp("UseAbility"))
        {
            dashFX.SetActive(false);
        }
    }
    public void ChangeAbility(int AbVal)
    {
        //data is still available for grenade and dash but is no longer used
        //both abilites use there own button
        LastAbility = ActiveAbility;
        //heal
        if (AbVal == 1)
        {
            ActiveAbility = 1;
            CurrentAbCoolDown = AbilityCooldowns[0];
            CurrentAbOBJ = AbilityOBJs[0];
            CurrentLogo.sprite = AbilityLogo[0];
            CurrentAbility.text = "" + AbilityNames[0];
            AbilLogo2.sprite = AbilityLogo[0];
        }
        //grenade
        if (AbVal == 2)
        {
            ActiveAbility = 2;
            CurrentAbCoolDown = AbilityCooldowns[1];
            CurrentAbOBJ = AbilityOBJs[1];
            CurrentLogo.sprite = AbilityLogo[1];
            CurrentAbility.text = "" + AbilityNames[1];
            AbilLogo2.sprite = AbilityLogo[1];
        }
        //dash
        if (AbVal == 3)
        {
            ActiveAbility = 3;
            CurrentAbCoolDown = AbilityCooldowns[2];
            CurrentAbOBJ = AbilityOBJs[0];
            CurrentLogo.sprite = AbilityLogo[2];
            CurrentAbility.text = "" + AbilityNames[2];
            AbilLogo2.sprite = AbilityLogo[2];
        }
        //hunter
        if (AbVal == 4)
        {
            ActiveAbility = 4;
            CurrentAbCoolDown = AbilityCooldowns[3];
            CurrentAbOBJ = AbilityOBJs[2];
            CurrentLogo.sprite = AbilityLogo[3];
            CurrentAbility.text = "" + AbilityNames[3];
            AbilLogo2.sprite = AbilityLogo[3];
        }
        //gravity
        if (AbVal == 5)
        {
            ActiveAbility = 5;
            CurrentAbCoolDown = AbilityCooldowns[4];
            CurrentAbOBJ = AbilityOBJs[3];
            CurrentLogo.sprite = AbilityLogo[4];
            CurrentAbility.text = "" + AbilityNames[4];
            AbilLogo2.sprite = AbilityLogo[4];
        }
    }
    public void AbilitySwap()
    {
        ChangeAbility(LastAbility);
    }
    //these coroutines manage the cooldown of each ability
    IEnumerator AbilityCooling()
    {
        yield return new WaitForSeconds(CurrentAbCoolDown);
        OnCooldown = false;
        AbilityVis.fillAmount = 0;
        AbilFullIcon.SetActive(false);
    }
    IEnumerator GrenadeCooling()
    {
        yield return new WaitForSeconds(AbilityCooldowns[1]);
        GrenadeDown = false;
        GrenadeVis.fillAmount = 0;
        GrenadeFullIcon.SetActive(false);
    }
    IEnumerator DodgeCooling()
    {
        yield return new WaitForSeconds(AbilityCooldowns[2]);
        DodgeDown = false;
        DodgeVis.fillAmount = 0;
        DodgeFullIcon.SetActive(false);
    }
    IEnumerator HealingFX()
    {
        PlayerHealth Healing = gameObject.GetComponent<PlayerHealth>();
        Healing.RestoreHealth();
        Healing.ShieldCounter = 10;
        HealFX.SetActive(true);
        yield return new WaitForSeconds(10f);
        HealFX.SetActive(false);
    }
}
