﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextPopUp : MonoBehaviour
{
    public GameObject TextOBJ;
    public void ShowText()
    {
        TextOBJ.SetActive(true);
    }
    public void HideText()
    {
        TextOBJ.SetActive(false);
    }
}
