﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
    public GameObject[] Menus;
    public void ChangeScene(int sceneNumber)
    {
        SceneManager.LoadScene(sceneNumber);
        Time.timeScale = 1;
    }
    public void Quit()
    {
        Application.Quit();
    }
    //used for the main menu, when a button is clicked it will hide all menus and then show the menu that was clicked on
    public void ChangeMenu(int MenuNum)
    {
        foreach (GameObject Menu in Menus)
        {
            Menu.SetActive(false);
        }
        Menus[MenuNum].SetActive(true);
    }
    public void Restart(int sceneNumber)
    {
        PlayerPrefs.SetInt("Restart", 1);
        PlayerPrefs.SetInt("SpawnPoint", 0);
        PlayerPrefs.Save();
        SceneManager.LoadScene(sceneNumber);
        Time.timeScale = 1;
    }
}
