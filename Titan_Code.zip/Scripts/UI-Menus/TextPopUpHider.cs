﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextPopUpHider : MonoBehaviour
{
    //used for when the player releases Q or weapon wheel without clicking an item first
    public GameObject[] TextOBJList;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonUp("Weapons"))
        {
            foreach (GameObject Text in TextOBJList)
            {
                Text.SetActive(false);
            }
        }
    }
}
