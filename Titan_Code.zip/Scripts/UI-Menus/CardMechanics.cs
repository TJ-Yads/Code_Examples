﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardMechanics : MonoBehaviour
{
    private CMF.CameraController CameraController;
    private GameObject Parent;
    public bool IsPickup;
    // Start is called before the first frame update
    void Start()
    {
        if (IsPickup)
        {
            Parent = GameObject.FindWithTag("CardTarget");
            gameObject.transform.parent = Parent.transform;
        }
    }
    public void CloseCard()
    {
        GameObject playerControllerObject = GameObject.FindWithTag("Player");
        CameraController = playerControllerObject.GetComponentInChildren<CMF.CameraController>();
        CameraController.enabled = true;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        Time.timeScale = 1;
        Destroy(gameObject);
    }
}
