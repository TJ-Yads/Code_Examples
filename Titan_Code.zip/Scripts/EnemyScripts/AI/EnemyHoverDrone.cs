﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyHoverDrone : MonoBehaviour
{
    //this script is used for basic AI enemies that will fire any single projectile such as a sniper or rifleman
    public float shotForce;

    public NavMeshAgent agent;

    public GameObject enemyBullet;
    public GameObject spawn;

    GameObject player;
    GameObject enemyAim;


    private float LastFired, LastHealed;
    public float FireRate, HealRate;
    private float ColdModifier = 1;
    public float MaxDistance, AuraDistance;
    public int Speed;
    public GameObject ColdFX, HealingFX;
    public float DMGVal;
    public SphereCollider DetectionRange;
    public bool NoMove;

    private void Start()
    {

        player = GameObject.FindGameObjectWithTag("Player");
        enemyAim = GameObject.FindGameObjectWithTag("enemyAimPoint");
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" && agent.isActiveAndEnabled == true && NoMove == false)
        {
            agent.speed = Speed;
        }
        if (other.tag == "bullet1" && agent.isActiveAndEnabled == true)
        {
            DetectionRange.radius = 75;
        }
    }
    //while the player is inside the enemies range of view the enemy will shoot so long as the player is in line of sight to the enemy
    private void OnTriggerStay(Collider other)
    {
        //used for when the drone is a ground unit
        if (other.gameObject.CompareTag("Player") && agent.isActiveAndEnabled == true && NoMove == false)
        {
            spawn.transform.LookAt(enemyAim.transform.position);

            agent.SetDestination(player.transform.position);

            RaycastHit hit;
            if (Physics.Raycast(spawn.transform.position, spawn.transform.TransformDirection(Vector3.forward), out hit))
            {
                Collider HitCollider = player.GetComponent<Collider>();
                if (hit.collider == HitCollider)
                {
                    if (Time.time - LastFired > FireRate * ColdModifier && Vector3.Distance(transform.position, player.transform.position) < MaxDistance)
                    {
                        LastFired = Time.time;
                        ShootAtPlayer();
                    }
                }
                Debug.DrawRay(spawn.transform.position, spawn.transform.TransformDirection(Vector3.forward) * hit.distance, Color.yellow);
            }
        }

        //used for the drone as a out of bounds hover unit
        if (other.gameObject.CompareTag("Player") && NoMove == true)
        {
            spawn.transform.LookAt(enemyAim.transform.position);
            RaycastHit hit;
            if (Physics.Raycast(spawn.transform.position, spawn.transform.TransformDirection(Vector3.forward), out hit))
            {
                Collider HitCollider = player.GetComponent<Collider>();
                if (hit.collider == HitCollider)
                {
                    if (Time.time - LastFired > FireRate * ColdModifier && Vector3.Distance(transform.position, player.transform.position) < MaxDistance)
                    {
                        LastFired = Time.time;
                        ShootAtPlayer();
                    }
                }
                Debug.DrawRay(spawn.transform.position, spawn.transform.TransformDirection(Vector3.forward) * hit.distance, Color.yellow);
            }
        }
        //used for the healing ability
        if (other.gameObject.CompareTag("Enemy") && Vector3.Distance(transform.position, other.transform.position) < AuraDistance)
        {
            if (Time.time - LastHealed > HealRate * ColdModifier)
            {
                LastHealed = Time.time;
                GameObject EnemyHit = other.gameObject;
                EnemyHealth HitReact = EnemyHit.GetComponentInChildren<EnemyHealth>();
                HitReact.Hurt(DMGVal);
                Instantiate(HealingFX, other.transform.position, other.transform.rotation);
            }
        }
    }


    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Player") && agent.isActiveAndEnabled == true)
        {

            agent.speed = 0;
        }
    }
    //used for the ice status effect which will slow attack speed
    public IEnumerator Cold()
    {
        agent.speed = Speed - 4;
        ColdFX.SetActive(true);
        ColdModifier = 1.5f;
        yield return new WaitForSeconds(4f);
        ColdFX.SetActive(false);
        ColdModifier = 1;
        agent.speed = Speed;
    }
    public void HitCold()
    {
        StartCoroutine(Cold());
    }
    //when activated a bullet will fire from enemy to player
    void ShootAtPlayer()
    {
        GameObject bullets = Instantiate(enemyBullet, spawn.transform.position, spawn.transform.rotation);
        Rigidbody rb2 = bullets.GetComponent<Rigidbody>();
        rb2.AddForce(spawn.transform.forward * shotForce, ForceMode.VelocityChange);

        Destroy(bullets, 5f);
    }
}
