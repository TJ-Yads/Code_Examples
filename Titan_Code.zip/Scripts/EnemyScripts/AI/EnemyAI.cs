﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyAI : MonoBehaviour
{
    //enemy AI is used for the basic melee AI
    public NavMeshAgent agent;

    GameObject player;

    public Animator anim;

    private float LastFired;
    public float AttackSpeed;
    private float ColdModifier = 1;
    public int AttackDMG;
    public GameObject AttackVis;
    public int Speed;
    public GameObject ColdFX;
    public SphereCollider DetectionRange;

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" && agent.isActiveAndEnabled == true)
        {
            agent.speed = Speed;
        }
        if (other.tag == "bullet1" && agent.isActiveAndEnabled == true)
        {
            DetectionRange.radius = 60;
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.CompareTag("Player") && agent.isActiveAndEnabled == true)
        {
            anim.SetBool("enemyRun", true);

            agent.SetDestination(player.transform.position);
            if (Time.time - LastFired > AttackSpeed * ColdModifier && Vector3.Distance(transform.position, player.transform.position) < 4)
            {
                StartCoroutine(BasicAttack());
                LastFired = Time.time;
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Player") && agent.isActiveAndEnabled == true)
        {
            anim.SetBool("enemyRun", false);

            agent.speed = 0;
        }
    }
    public IEnumerator Cold()
    {
        agent.speed = Speed - 4;
        ColdFX.SetActive(true);
        ColdModifier = 1.5f;
        yield return new WaitForSeconds(4f);
        ColdFX.SetActive(false);
        ColdModifier = 1;
        agent.speed = Speed;
    }
    public void HitCold()
    {
        StartCoroutine(Cold());
    }
    //when active it will swipe at the player and deal damage if the player is still nearby
    IEnumerator BasicAttack()
    {
        agent.speed = 0;
        yield return new WaitForSeconds(.6f);
        Instantiate(AttackVis, transform.position, transform.rotation);
        if (Vector3.Distance(transform.position, player.transform.position) < 4)
        {
            GameObject PlayerHit = player.gameObject;
            PlayerHealth HitReact = PlayerHit.GetComponent<PlayerHealth>();
            HitReact.TakingDMG(AttackDMG);
        }
        yield return new WaitForSeconds(.6f);
        agent.speed = Speed;
    }
}