﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyKnight : MonoBehaviour
{
    //this script controls the AI of the knight
    public NavMeshAgent agent;

    GameObject player;

    public Animator anim;

    private float LastFired;
    public float AttackSpeed, SlamCooldown;
    private float ColdModifier = 1;
    public int AttackDMG;
    private bool SlamCooling;
    public GameObject SlamOBJ, AimTarget, SlamSpawn, AttackVis;
    public int Speed;
    public GameObject ColdFX;
    public SphereCollider DetectionRange;

    private void Start()
    {
        AimTarget = GameObject.FindGameObjectWithTag("enemyAimPoint");
        player = GameObject.FindGameObjectWithTag("Player");
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" && agent.isActiveAndEnabled == true)
        {
            agent.speed = Speed;
        }
        if (other.tag == "bullet1" && agent.isActiveAndEnabled == true)
        {
            DetectionRange.radius = 70;
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.CompareTag("Player") && agent.isActiveAndEnabled == true)
        {
            anim.SetBool("enemyRun", true);

            agent.SetDestination(player.transform.position);
            //if the enemy distance is at the proper value and the knight is not cooling down then they will start the slam wave attack
            if (Time.time - LastFired > AttackSpeed * ColdModifier && Vector3.Distance(transform.position, player.transform.position) < 13 && Vector3.Distance(transform.position, player.transform.position) > 8)
            {
                SlamSpawn.transform.LookAt(AimTarget.transform.position);
                if (SlamCooling == false)
                {
                    LastFired = Time.time;
                    StartCoroutine(SlamCool());
                }
            }
            //the basic attack of the knight when near the player
            if (Time.time - LastFired > AttackSpeed * ColdModifier && Vector3.Distance(transform.position, player.transform.position) < 4)
            {
                StartCoroutine(BasicAttack());
                LastFired = Time.time;
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("Player") && agent.isActiveAndEnabled == true)
        {
            anim.SetBool("enemyRun", false);

            agent.speed = 0;
        }
    }
    public IEnumerator Cold()
    {
        agent.speed = Speed - 4;
        ColdFX.SetActive(true);
        ColdModifier = 1.5f;
        yield return new WaitForSeconds(4f);
        ColdFX.SetActive(false);
        ColdModifier = 1;
        agent.speed = Speed;
    }
    public void HitCold()
    {
        StartCoroutine(Cold());
    }
    //when active it will create the slam and start its cooldown
    IEnumerator SlamCool()
    {
        agent.speed = 0;
        SlamCooling = true;
        yield return new WaitForSeconds(1f);
        Instantiate(SlamOBJ, SlamSpawn.transform.position, SlamSpawn.transform.rotation);
        yield return new WaitForSeconds(1f);
        agent.speed = 5.5f;
        yield return new WaitForSeconds(SlamCooldown);
        SlamCooling = false;
    }
    //when active it will swipe at the player and deal damage if the player is still nearby
    IEnumerator BasicAttack()
    {
        agent.speed = 0;
        yield return new WaitForSeconds(1f);
        Instantiate(AttackVis, SlamSpawn.transform.position, SlamSpawn.transform.rotation);
        if (Vector3.Distance(transform.position, player.transform.position) < 4)
        {
            GameObject PlayerHit = player.gameObject;
            PlayerHealth HitReact = PlayerHit.GetComponent<PlayerHealth>();
            HitReact.TakingDMG(AttackDMG);
        }
        yield return new WaitForSeconds(1f);
        agent.speed = 5.5f;
    }
}
