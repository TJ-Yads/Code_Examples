﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletMovement : MonoBehaviour
{
    public float shotForce, MaxAc, MinAc;

    private Rigidbody rb;
    private float AccuracyX, AccuracyY;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            AccuracyX = Random.Range(MinAc, MaxAc);
            AccuracyY = Random.Range(MinAc, MaxAc);
            transform.Rotate(AccuracyX, AccuracyY, 0);
            rb.AddForce(transform.forward * shotForce, ForceMode.VelocityChange);
        }
    }

}
