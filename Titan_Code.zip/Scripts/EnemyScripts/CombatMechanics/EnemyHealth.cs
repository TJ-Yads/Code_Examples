﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    private float MaxHealth = 5;
    public float health;

    public GameObject enemy;
    public GameObject enemyRag;
    public GameObject ragSpawn;
    public GameObject exSpawn;
    public GameObject explosionForce;
    public GameObject AmmoPickup;
    public GameObject WeaponPickup;
    public GameObject FireFX;
    public int[] AmmoCount;

    public bool Frozen, Burned, FreezeDown, BurnDown;
    private SaveStats StatSaver;


    //updated health scripted allows the enemy to take variable damage based off bullet behaviors DMG value

    public void Hurt(float DMG)
    {
        health -= DMG;
        if (Burned && BurnDown == false)
        {
            BurnDown = true;
            StartCoroutine(Burning());
        }
        if (Frozen && FreezeDown == false)
        {
            FreezeDown = true;
            StartCoroutine(Freezing());
        }
        if (health > MaxHealth)
        {
            health = MaxHealth;
        }
        if (health <= 0)
        {
            GameObject GameController = GameObject.FindGameObjectWithTag("GameController");
            StatSaver = GameController.GetComponent<SaveStats>();
            StatSaver.Kills += 1;
            foreach (int Count in AmmoCount)
            {
                Instantiate(AmmoPickup, ragSpawn.transform.position, ragSpawn.transform.rotation);
            }
            if (WeaponPickup != null)
            {
                Instantiate(WeaponPickup, ragSpawn.transform.position, ragSpawn.transform.rotation);
            }
            Instantiate(enemyRag, ragSpawn.transform.position, ragSpawn.transform.rotation);
            Instantiate(explosionForce, exSpawn.transform.position, exSpawn.transform.rotation);
            enemy.SetActive(false);
        }
    }

    public IEnumerator Burning()
    {
        FireFX.SetActive(true);
        yield return new WaitForSeconds(.5f);
        Hurt(.25f);
        yield return new WaitForSeconds(.5f);
        Hurt(.25f);
        yield return new WaitForSeconds(.5f);
        Hurt(.25f);
        FireFX.SetActive(false);
        Burned = false;
        BurnDown = false;
    }

    public IEnumerator Freezing()
    {
        EnemyShooterAI HitReact = GetComponentInChildren<EnemyShooterAI>();
        if (HitReact != null)
        {
            HitReact.HitCold();
        }
        EnemyAI HitReact2 = GetComponentInChildren<EnemyAI>();
        if (HitReact2 != null)
        {
            HitReact2.HitCold();
        }
        EnemyKnight HitReact3 = GetComponentInChildren<EnemyKnight>();
        if (HitReact3 != null)
        {
            HitReact3.HitCold();
        }
        EnemyKingAI HitReact4 = GetComponentInChildren<EnemyKingAI>();
        if (HitReact4 != null)
        {
            HitReact4.HitCold();
        }
        yield return new WaitForSeconds(4f);
        Frozen = false;
        FreezeDown = false;
    }

}
