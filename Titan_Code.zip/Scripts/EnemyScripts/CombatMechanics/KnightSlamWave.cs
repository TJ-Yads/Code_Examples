﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnightSlamWave : MonoBehaviour
{
    public int DMGVal;
    void Update()
    {
        Destroy(gameObject, .85f);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            gameObject.SetActive(false);
            GameObject PlayerHit = other.gameObject;
            PlayerHealth HitReact = PlayerHit.GetComponent<PlayerHealth>();
            HitReact.TakingDMG(DMGVal);
        }
        if (other.tag == "ENV_OBJ")
        {
            gameObject.SetActive(false);
            GameObject PlayerHit = other.gameObject;
            PlayerHealth HitReact = PlayerHit.GetComponent<PlayerHealth>();
            HitReact.TakingDMG(DMGVal);
        }
    }
}
