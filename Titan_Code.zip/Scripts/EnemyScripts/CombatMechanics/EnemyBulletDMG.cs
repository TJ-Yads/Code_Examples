﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletDMG : MonoBehaviour
{
    public GameObject hitFX;
    public GameObject explosionFX;
    public GameObject Bomb;

    //DMGVal is the damage each pellet will do to enemies while the bools allow a bullet to freeze or burn enemies and explosive allows the rocket to spawn a explosion
    public int DMGVal;
    public bool Frost, Fire, Explosive;
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "ENV_OBJ")
        {
            Instantiate(explosionFX, transform.position, transform.rotation);
            Instantiate(hitFX, transform.position, transform.rotation);
            gameObject.SetActive(false);
        }
        if (other.tag == "Player")
        {
            Instantiate(explosionFX, transform.position, transform.rotation);
            Instantiate(hitFX, transform.position, transform.rotation);
            GameObject PlayerHit = other.gameObject;
            PlayerHealth HitReact = PlayerHit.GetComponent<PlayerHealth>();
            if (Frost)
            {
                //HitReact.Frozen = true;
            }
            if (Fire)
            {
                //HitReact.Burned = true;
            }
            if (Explosive)
            {
                Instantiate(Bomb, transform.position, transform.rotation);
            }
            HitReact.TakingDMG(DMGVal);
            gameObject.SetActive(false);
        }
    }
}
