﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyKnightSlam : MonoBehaviour
{
    //this script is used to spawn the knights slam and wave AOE attack
    public GameObject[] SpawnPoints;
    public GameObject Wave;
    public GameObject Slam;
    public int DMGVal;

    void Start()
    {
        StartCoroutine(WaveSpawner());
    }
    IEnumerator WaveSpawner()
    {
        Instantiate(Wave, SpawnPoints[0].transform.position, SpawnPoints[0].transform.rotation);
        yield return new WaitForSeconds(.5f);
        Instantiate(Wave, SpawnPoints[1].transform.position, SpawnPoints[1].transform.rotation);
        yield return new WaitForSeconds(.5f);
        Instantiate(Wave, SpawnPoints[2].transform.position, SpawnPoints[2].transform.rotation);
        yield return new WaitForSeconds(.5f);
        Instantiate(Wave, SpawnPoints[3].transform.position, SpawnPoints[3].transform.rotation);
    }
    // Update is called once per frame
    void Update()
    {
        Destroy(gameObject, 5f);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            GameObject PlayerHit = other.gameObject;
            PlayerHealth HitReact = PlayerHit.GetComponent<PlayerHealth>();
            HitReact.TakingDMG(DMGVal);
        }
    }
}
