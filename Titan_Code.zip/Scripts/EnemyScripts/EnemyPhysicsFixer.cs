﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyPhysicsFixer : MonoBehaviour
{
    //this script will re-enable the kinematic and nav mesh of any enemy who was hit by gravity well
    public bool NoPhysics;
    private float Cooldown;

    // Update is called once per frame
    void Update()
    {
        if (NoPhysics == true)
        {
            Cooldown += Time.deltaTime;
            if (Cooldown >= 8f)
            {
                GetComponent<NavMeshAgent>().enabled = true;
                GetComponent<Rigidbody>().isKinematic = true;
                NoPhysics = false;
                Cooldown = 0;
            }
        }
    }
}
