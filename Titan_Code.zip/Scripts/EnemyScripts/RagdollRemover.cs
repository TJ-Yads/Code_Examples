﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RagdollRemover : MonoBehaviour
{
    //currently used for removing prefabs that dont have any way to be removed yet
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Remover());
    }
    IEnumerator Remover()
    {
        yield return new WaitForSeconds(10f);
        Destroy(gameObject);
    }
}
