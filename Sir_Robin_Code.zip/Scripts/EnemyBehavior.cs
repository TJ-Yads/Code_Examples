﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyBehavior : MonoBehaviour {
    //values for zombie health and points
    public float health;
    private float healthModify = 1;
    public float trueHealth;
    private float DmgReduction = 1;
    public int scoreValue;
    private float RocketCounter = 1;
    //values for targeting the player
    private Transform Player;
    public float MoveSpeed;
    private float SpeedModify = 1;
    private float SpeedIncrease = 0;
    public float MaxDist;
    public float MinDist;
    //values for attacking
    public float AttackSpeed;
    private float nextHit;
    public GameObject HitAttack;
    public Transform HitSpawn;
    public GameObject DeathEffect;
    public Transform DeathSpawn;
    public GameObject DeathSound;
    public AudioSource RandomNoise;
    private float AudioCounter = 0;

    private PlayerController playercontroller;
    private GameController gameController;
    private float counter = 0;
    // Use this for initialization
    void Start () {
        GameObject playerControllerObject = GameObject.FindWithTag("Player");
        playercontroller = playerControllerObject.GetComponent<PlayerController>();
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gameController = gameControllerObject.GetComponent<GameController>();
        SpeedIncrease += .025f * gameController.waveTotal;
        healthModify += .05f * gameController.waveTotal;
        MoveSpeed = SpeedIncrease + MoveSpeed;
        if (MoveSpeed >= 10.5)
        {
            MoveSpeed = 10.5f;
        }
        trueHealth = health * healthModify;
        Player = GameObject.FindWithTag("Player").transform;
        RandomNoiseMethod();
    }

    private void FixedUpdate()
    {
        if (gameController.Death == true)
        {
            Destroy(gameObject);
        }
        if (trueHealth <= 0)
        {
            Destroy(gameObject);
            playercontroller.AddScore(scoreValue);
            gameController.ZomsAlive -= 1;
            gameController.ZomsLeft -= 1;
            gameController.ZomsKilled += 1;
            Instantiate(DeathEffect, DeathSpawn.position, DeathSpawn.rotation);
            Instantiate(DeathSound, DeathSpawn.position, DeathSpawn.rotation);
        }

        Vector3 Target = Player.transform.position;
        float TrueSpeed = MoveSpeed * SpeedModify * Time.deltaTime;
        if (Vector3.Distance(transform.position, Player.position) >= MinDist)
        {
            transform.position = Vector3.MoveTowards(transform.position, Target, TrueSpeed);
            //transform.position += transform.forward * MoveSpeed * Time.deltaTime * SpeedModify;
        }
        if (Vector3.Distance(transform.position, Player.position) <= MinDist && Time.time > nextHit)
        {
            nextHit = Time.time + AttackSpeed;
            Instantiate(HitAttack, HitSpawn.position, HitSpawn.rotation);
        }
        transform.LookAt(Player);
        AudioCounter += Time.deltaTime;
        if (AudioCounter >= 7)
        {
            RandomNoiseMethod();
            AudioCounter = 0;
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "PistolBolt")
        {
            trueHealth -= 1 * playercontroller.dmgBonus * DmgReduction;
        }
        if (other.tag == "RifleBolt")
        {
            trueHealth -= 2 * playercontroller.dmgBonus * DmgReduction;
        }
        if (other.tag == "FireBomb")
        {
            trueHealth -= 75 * playercontroller.dmgBonus * DmgReduction;
        }
        if (other.tag == "RocketBolt")
        {
            trueHealth -= 10 * playercontroller.dmgBonus * DmgReduction;
            StartCoroutine(Stunned());
        }
        if (other.tag == "RocketBomb" && RocketCounter >= 1)
        {
            trueHealth -= 22 * playercontroller.dmgBonus * DmgReduction;
            RocketCounter = 0;
            StartCoroutine(RocketCounterCo());
        }
        if (other.tag == "SniperBolt")
        {
            trueHealth -= 45 * playercontroller.dmgBonus * DmgReduction;
            StartCoroutine(Slowed());
        }
        if (other.tag == "RailgunBolt")
        {
            trueHealth -= 25 * playercontroller.dmgBonus * DmgReduction;
            StartCoroutine(Stunned());
        }
        if (other.tag == "SweeperBolt")
        {
            trueHealth -= 15 * playercontroller.dmgBonus * DmgReduction;
            StartCoroutine(Slowed());
        }
        if (other.tag == "UnknownBolt")
        {
            trueHealth -= 20 * playercontroller.dmgBonus;
            StartCoroutine(Slowed());
        }
        if (other.tag == "BlasterBolt")
        {
            trueHealth -= 25 * playercontroller.dmgBonus * DmgReduction;
            StartCoroutine(Slowed());
        }
        if (other.tag == "BlasterBomb")
        {
            trueHealth -= 20 * playercontroller.dmgBonus * DmgReduction;
            StartCoroutine(Slowed());
        }
        if (other.tag == "RShotgunBolt")
        {
            trueHealth -= 2 * playercontroller.dmgBonus * DmgReduction;
        }
        if (other.tag == "EBomb")
        {
            trueHealth -= 125 * playercontroller.dmgBonus * DmgReduction;
        }
        if (other.tag == "Nuke")
        {
            trueHealth -= 200 * playercontroller.dmgBonus * DmgReduction;
            StartCoroutine(Stunned());
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "SlowZone")
        {
            StartCoroutine(Slowed());
        }
        if (other.tag == "NukeZone")
        {
            StartCoroutine(Slowed());
            counter += Time.deltaTime;
            if (counter >= 1)
            {
                trueHealth -= 8 * playercontroller.dmgBonus * DmgReduction;
                counter = 0;
            }
        }
        if (other.tag == "ZomFire")
        {
            counter += Time.deltaTime;
            if (counter >= 1.5)
            {
                trueHealth += 10;
                counter = 0;
            }
        }
        if (other.tag == "ZomReduce")
        {
            StartCoroutine(DMGReduction());
        }
    }
    public IEnumerator Stunned()
    {
        SpeedModify = .01f;
        yield return new WaitForSeconds(2f);
        SpeedModify = 1;
        StopCoroutine(Stunned());
    }
    public IEnumerator Slowed()
    {
        SpeedModify = .66f;
        yield return new WaitForSeconds(4f);
        SpeedModify = 1;
        StopCoroutine(Slowed());
    }
    public IEnumerator DMGReduction()
    {
        DmgReduction = .5f;
        yield return new WaitForSeconds(5f);
        DmgReduction = 1;
        StopCoroutine(DMGReduction());
    }
    public IEnumerator RocketCounterCo()
    {
        yield return new WaitForSeconds(.75f);
        RocketCounter = 1;
        StopCoroutine(RocketCounterCo());
    }
    private void RandomNoiseMethod()
    {
        int RangeValue = Random.Range(0, 9);
        if (RangeValue ==1)
        {
            RandomNoise.Play();
        }
    }
}
