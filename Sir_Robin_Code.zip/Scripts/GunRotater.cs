﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunRotater : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        var point = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        transform.LookAt(new Vector3(point.x, transform.position.y, point.z));
    }
}
