﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyTimer : MonoBehaviour {
    private float counter = 0;
    public float lifetime;
    private GameController gameController;
    // Use this for initialization
    void Start () {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        gameController = gameControllerObject.GetComponent<GameController>();
    }
	
	// Update is called once per frame
	void Update () {
        counter += Time.deltaTime;
        if (counter >= lifetime)
        {
            Destroy(gameObject);
            gameController.ZomsAlive -= 1;
            gameController.ZomsLeft -= 1;
        }
    }
    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Boundary")
        {
            Destroy(gameObject);
            gameController.ZomsAlive -= 1;
            gameController.ZomsLeft -= 1;
        }
    }
}
