﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RailgunMechanics : MonoBehaviour {
    public GameObject RailgunShot;
    public Transform shotSpawn2;
    public Transform shotSpawn3;
    // Use this for initialization
    void Start () {
        StartCoroutine(Counter());
	}
	
	// Update is called once per frame
	void Update () {
    }
    public IEnumerator Counter()
    {
        yield return new WaitForSeconds(.07f);
            Instantiate(RailgunShot, shotSpawn2.position, shotSpawn2.rotation);
            Instantiate(RailgunShot, shotSpawn3.position, shotSpawn3.rotation);
        StopCoroutine(Counter());
    }
}
