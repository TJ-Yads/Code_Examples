﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrowthScale : MonoBehaviour {
    public float XValue;
    public float ZValues;
	// Use this for initialization
	void Start () {
        StartCoroutine(Scaler());
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public IEnumerator Scaler()
    {
        while (true)
        {
            transform.localScale += new Vector3(XValue, 0, ZValues);
            yield return new WaitForSeconds(.05f);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "GunZom")
        {
            Destroy(other.gameObject);
        }
    }
}
