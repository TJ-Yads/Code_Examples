﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// This script controls the gunner zombies bullets
/// </summary>
public class BulletTracker : MonoBehaviour {
    private Transform Player;
    public float MoveSpeed;
    public float MaxDist;
    public float MinDist;

    private PlayerController playercontroller;
    // Use this for initialization
    void Start () {
        Player = GameObject.FindWithTag("Player").transform;
    }
	
	// Update is called once per frame
	void Update () {
        transform.LookAt(Player);
        if (Vector3.Distance(transform.position, Player.position) >= MinDist)
        {
            transform.position += transform.forward * MoveSpeed * Time.deltaTime;
        }
        if (Vector3.Distance(transform.position, Player.position) >= MaxDist)
        {
            //Instantiate(HitAttack, HitSpawn.position, HitSpawn.rotation);
        }
        if (Vector3.Distance(transform.position, Player.position) <= MinDist)
        {
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Wall")
        {
            Destroy(gameObject);
        }
        if (other.tag == "UnknownBolt")
        {
            Destroy(gameObject);
        }
        if (other.tag == "SweeperBolt")
        {
            Destroy(gameObject);
        }
    }
}
