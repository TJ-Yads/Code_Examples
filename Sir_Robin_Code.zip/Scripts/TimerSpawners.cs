﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimerSpawners : MonoBehaviour {
    private float counter = 0;
    public float lifetime;
    public GameObject AOE;
    public Transform AOESpawn;
    // Use this for initialization
    void Start () {
        Instantiate(AOE, AOESpawn.position, AOESpawn.rotation);
    }
	
	// Update is called once per frame
	void Update () {
        counter += Time.deltaTime;
        if (counter >= lifetime)
        {
            Destroy(gameObject);
        }
    }
}
