﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnknownMechanics : MonoBehaviour {
    public GameObject Explosion;
    public GameObject ExplosionAudio;
    public GameObject ExplosionBolts;
    public Transform Explode;
    public Transform ExplodeBolts;
    public Transform ExplodeBolts2;
    public int PentLimit;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (PentLimit <= 0)
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Zombie")
        {
            PentLimit -= 1;
            Instantiate(Explosion, Explode.position, Explode.rotation);
            Instantiate(ExplosionAudio, Explode.position, Explode.rotation);
            Instantiate(ExplosionBolts, Explode.position, ExplodeBolts.rotation);
            Instantiate(ExplosionBolts, Explode.position, ExplodeBolts2.rotation);
        }
        if (other.tag == "Wall")
        {
            Instantiate(Explosion, Explode.position, Explode.rotation);
            Instantiate(ExplosionAudio, Explode.position, Explode.rotation);
            Destroy(gameObject);
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "BulletBound")
        {
            Destroy(gameObject);
        }
    }
}
