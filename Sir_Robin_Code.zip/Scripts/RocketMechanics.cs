﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketMechanics : MonoBehaviour {
    public GameObject Explosion;
    public Transform Explode;
    public GameObject ExplosionAudio;
    // Use this for initialization
    void Start () {
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Zombie")
        {
            Destroy(gameObject);
            Instantiate(Explosion, Explode.position, Explode.rotation);
            Instantiate(ExplosionAudio, Explode.position, Explode.rotation);
        }
        if (other.tag == "Wall")
        {
            Destroy(gameObject);
            Instantiate(Explosion, Explode.position, Explode.rotation);
            Instantiate(ExplosionAudio, Explode.position, Explode.rotation);
        }
    }
}
