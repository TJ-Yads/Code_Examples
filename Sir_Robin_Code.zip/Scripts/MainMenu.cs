﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {
    public GameObject[] Buttons;
    public GameObject[] Menus;
    public AudioSource ClickSound;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonDown("Pause"))
        {
            Buttons[0].SetActive(true);
            Buttons[1].SetActive(true);
            Buttons[2].SetActive(true);
            Menus[0].SetActive(false);
            Menus[1].SetActive(true);
            Menus[2].SetActive(false);
            ClickSound.Play();
        }
    }
    public void ChangeScene(string sceneName)
    {
        ClickSound.Play();
        SceneManager.LoadScene(sceneName);
    }
    public void ShowControls()
    {
        Menus[0].SetActive(true);
        Menus[1].SetActive(false);
        Menus[2].SetActive(true);
        Buttons[0].SetActive(false);
        Buttons[1].SetActive(false);
        Buttons[2].SetActive(false);
        ClickSound.Play();
    }
    public void Quit()
    {
        ClickSound.Play();
        Application.Quit();
    }
}
