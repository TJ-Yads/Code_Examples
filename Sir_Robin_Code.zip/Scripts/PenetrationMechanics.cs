﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PenetrationMechanics : MonoBehaviour {
    public int PentLimit;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (PentLimit <= 0)
        {
            Destroy(gameObject);
        }
	}
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Zombie")
        {
            PentLimit -= 1;
        }
        if (other.tag == "Wall")
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "ZomFire")
        {
            Destroy(gameObject);
        }
        if (other.tag == "BulletBound")
        {
            Destroy(gameObject);
        }
    }
}
