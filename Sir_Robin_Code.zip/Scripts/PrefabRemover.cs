﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrefabRemover : MonoBehaviour {
    private float counter = 0;
    public float lifetime;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        counter += Time.deltaTime;
        if (counter >= lifetime)
        {
            Destroy(gameObject);
        }
    }
}
